/********************************************************************************
** Form generated from reading UI file 'homeinfo.ui'
**
** Created by: Qt User Interface Compiler version 5.12.3
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_HOMEINFO_H
#define UI_HOMEINFO_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDialog>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_homeinfo
{
public:
    QLabel *error;
    QPushButton *confirm;
    QLabel *number;
    QWidget *widget;
    QHBoxLayout *horizontalLayout;
    QVBoxLayout *verticalLayout;
    QLineEdit *builtarea;
    QLineEdit *floornum;
    QLineEdit *rommsnum;
    QLineEdit *photo;
    QVBoxLayout *verticalLayout_2;
    QLabel *label;
    QLabel *label_7;
    QLabel *label_5;
    QLabel *label_6;

    void setupUi(QDialog *homeinfo)
    {
        if (homeinfo->objectName().isEmpty())
            homeinfo->setObjectName(QString::fromUtf8("homeinfo"));
        homeinfo->resize(465, 361);
        error = new QLabel(homeinfo);
        error->setObjectName(QString::fromUtf8("error"));
        error->setGeometry(QRect(130, 270, 201, 31));
        confirm = new QPushButton(homeinfo);
        confirm->setObjectName(QString::fromUtf8("confirm"));
        confirm->setGeometry(QRect(180, 220, 91, 31));
        number = new QLabel(homeinfo);
        number->setObjectName(QString::fromUtf8("number"));
        number->setGeometry(QRect(200, 20, 61, 31));
        widget = new QWidget(homeinfo);
        widget->setObjectName(QString::fromUtf8("widget"));
        widget->setGeometry(QRect(120, 80, 214, 122));
        horizontalLayout = new QHBoxLayout(widget);
        horizontalLayout->setObjectName(QString::fromUtf8("horizontalLayout"));
        horizontalLayout->setContentsMargins(0, 0, 0, 0);
        verticalLayout = new QVBoxLayout();
        verticalLayout->setObjectName(QString::fromUtf8("verticalLayout"));
        builtarea = new QLineEdit(widget);
        builtarea->setObjectName(QString::fromUtf8("builtarea"));

        verticalLayout->addWidget(builtarea);

        floornum = new QLineEdit(widget);
        floornum->setObjectName(QString::fromUtf8("floornum"));

        verticalLayout->addWidget(floornum);

        rommsnum = new QLineEdit(widget);
        rommsnum->setObjectName(QString::fromUtf8("rommsnum"));

        verticalLayout->addWidget(rommsnum);

        photo = new QLineEdit(widget);
        photo->setObjectName(QString::fromUtf8("photo"));

        verticalLayout->addWidget(photo);


        horizontalLayout->addLayout(verticalLayout);

        verticalLayout_2 = new QVBoxLayout();
        verticalLayout_2->setObjectName(QString::fromUtf8("verticalLayout_2"));
        label = new QLabel(widget);
        label->setObjectName(QString::fromUtf8("label"));
        QFont font;
        font.setFamily(QString::fromUtf8("Nasim"));
        font.setPointSize(12);
        label->setFont(font);
        label->setLayoutDirection(Qt::RightToLeft);

        verticalLayout_2->addWidget(label);

        label_7 = new QLabel(widget);
        label_7->setObjectName(QString::fromUtf8("label_7"));
        label_7->setFont(font);
        label_7->setLayoutDirection(Qt::RightToLeft);

        verticalLayout_2->addWidget(label_7);

        label_5 = new QLabel(widget);
        label_5->setObjectName(QString::fromUtf8("label_5"));
        label_5->setFont(font);
        label_5->setLayoutDirection(Qt::RightToLeft);

        verticalLayout_2->addWidget(label_5);

        label_6 = new QLabel(widget);
        label_6->setObjectName(QString::fromUtf8("label_6"));
        label_6->setFont(font);
        label_6->setLayoutDirection(Qt::RightToLeft);

        verticalLayout_2->addWidget(label_6);


        horizontalLayout->addLayout(verticalLayout_2);


        retranslateUi(homeinfo);

        QMetaObject::connectSlotsByName(homeinfo);
    } // setupUi

    void retranslateUi(QDialog *homeinfo)
    {
        homeinfo->setWindowTitle(QApplication::translate("homeinfo", "Dialog", nullptr));
        error->setText(QString());
        confirm->setText(QApplication::translate("homeinfo", "\330\252\330\243\333\214\333\214\330\257", nullptr));
        number->setText(QString());
        label->setText(QApplication::translate("homeinfo", "\331\205\330\263\330\247\330\255\330\252 \330\263\330\247\330\256\330\252:", nullptr));
        label_7->setText(QApplication::translate("homeinfo", "\330\264\331\205\330\247\330\261\331\207 \330\267\330\250\331\202\331\207:", nullptr));
        label_5->setText(QApplication::translate("homeinfo", "\330\252\330\271\330\257\330\247\330\257 \330\247\330\252\330\247\331\202:", nullptr));
        label_6->setText(QApplication::translate("homeinfo", "\330\271\332\251\330\263 \331\205\330\263\332\251\331\206:", nullptr));
    } // retranslateUi

};

namespace Ui {
    class homeinfo: public Ui_homeinfo {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_HOMEINFO_H
