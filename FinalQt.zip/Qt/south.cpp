#include "south.h"



south::south()
{
	yardArea = 0;
	parkingArea = 0;
}

south::south(int _builtArea, int _yardArea, int _parkingArea, int _totalArea, int _roomsNum, string _photo, int _baseCost, string _address) : villa(_totalArea, _builtArea, _baseCost, _roomsNum, _address, _photo)
{
	parkingArea = _parkingArea;
	yardArea = _yardArea;
}

void south::setareayard(int _yardArea)
{
	yardArea = _yardArea;
}

int south::getareayard()
{
	return yardArea;
}

void south::setParkingArea(int _parkingArea)
{
	parkingArea = _parkingArea;
}

int south::getParkingArea()
{
	return parkingArea;
}

long long int south::computetotalcost()
{
	return baseCost*builtArea + (baseCost*yardArea*0.3) + (baseCost*parkingArea*0.15);
}

south::~south()
{
}
