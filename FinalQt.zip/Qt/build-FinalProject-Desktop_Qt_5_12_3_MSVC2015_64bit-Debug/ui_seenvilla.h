/********************************************************************************
** Form generated from reading UI file 'seenvilla.ui'
**
** Created by: Qt User Interface Compiler version 5.12.3
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_SEENVILLA_H
#define UI_SEENVILLA_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDialog>
#include <QtWidgets/QLabel>
#include <QtWidgets/QTextEdit>

QT_BEGIN_NAMESPACE

class Ui_seenvilla
{
public:
    QLabel *error;
    QTextEdit *textEdit;

    void setupUi(QDialog *seenvilla)
    {
        if (seenvilla->objectName().isEmpty())
            seenvilla->setObjectName(QString::fromUtf8("seenvilla"));
        seenvilla->resize(510, 492);
        error = new QLabel(seenvilla);
        error->setObjectName(QString::fromUtf8("error"));
        error->setGeometry(QRect(40, 260, 47, 13));
        textEdit = new QTextEdit(seenvilla);
        textEdit->setObjectName(QString::fromUtf8("textEdit"));
        textEdit->setGeometry(QRect(110, 10, 281, 471));

        retranslateUi(seenvilla);

        QMetaObject::connectSlotsByName(seenvilla);
    } // setupUi

    void retranslateUi(QDialog *seenvilla)
    {
        seenvilla->setWindowTitle(QApplication::translate("seenvilla", "Dialog", nullptr));
        error->setText(QApplication::translate("seenvilla", "TextLabel", nullptr));
    } // retranslateUi

};

namespace Ui {
    class seenvilla: public Ui_seenvilla {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_SEENVILLA_H
