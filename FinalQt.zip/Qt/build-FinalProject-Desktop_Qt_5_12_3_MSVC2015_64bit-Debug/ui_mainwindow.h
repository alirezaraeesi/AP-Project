/********************************************************************************
** Form generated from reading UI file 'mainwindow.ui'
**
** Created by: Qt User Interface Compiler version 5.12.3
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAINWINDOW_H
#define UI_MAINWINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QLabel>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QRadioButton>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MainWindow
{
public:
    QWidget *centralWidget;
    QLabel *titr;
    QRadioButton *radioButtonm;
    QRadioButton *radioButtonu;
    QLabel *label;
    QPushButton *signin;
    QPushButton *signup;
    QLabel *error;
    QStatusBar *statusBar;

    void setupUi(QMainWindow *MainWindow)
    {
        if (MainWindow->objectName().isEmpty())
            MainWindow->setObjectName(QString::fromUtf8("MainWindow"));
        MainWindow->resize(400, 300);
        QSizePolicy sizePolicy(QSizePolicy::Fixed, QSizePolicy::Fixed);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(MainWindow->sizePolicy().hasHeightForWidth());
        MainWindow->setSizePolicy(sizePolicy);
        MainWindow->setCursor(QCursor(Qt::ArrowCursor));
        centralWidget = new QWidget(MainWindow);
        centralWidget->setObjectName(QString::fromUtf8("centralWidget"));
        titr = new QLabel(centralWidget);
        titr->setObjectName(QString::fromUtf8("titr"));
        titr->setGeometry(QRect(60, 10, 281, 51));
        QFont font;
        font.setFamily(QString::fromUtf8("Nasim"));
        font.setPointSize(20);
        font.setBold(false);
        font.setItalic(false);
        font.setUnderline(false);
        font.setWeight(50);
        font.setStrikeOut(false);
        font.setKerning(false);
        font.setStyleStrategy(QFont::PreferAntialias);
        titr->setFont(font);
        radioButtonm = new QRadioButton(centralWidget);
        radioButtonm->setObjectName(QString::fromUtf8("radioButtonm"));
        radioButtonm->setGeometry(QRect(210, 100, 82, 17));
        QFont font1;
        font1.setFamily(QString::fromUtf8("Nasim"));
        font1.setPointSize(10);
        radioButtonm->setFont(font1);
        radioButtonm->setCursor(QCursor(Qt::PointingHandCursor));
        radioButtonu = new QRadioButton(centralWidget);
        radioButtonu->setObjectName(QString::fromUtf8("radioButtonu"));
        radioButtonu->setGeometry(QRect(130, 100, 82, 17));
        radioButtonu->setFont(font1);
        radioButtonu->setCursor(QCursor(Qt::PointingHandCursor));
        label = new QLabel(centralWidget);
        label->setObjectName(QString::fromUtf8("label"));
        label->setGeometry(QRect(125, 70, 141, 20));
        label->setFont(font1);
        signin = new QPushButton(centralWidget);
        signin->setObjectName(QString::fromUtf8("signin"));
        signin->setGeometry(QRect(140, 150, 111, 41));
        QFont font2;
        font2.setFamily(QString::fromUtf8("B Sara"));
        font2.setPointSize(15);
        signin->setFont(font2);
        signin->setCursor(QCursor(Qt::PointingHandCursor));
        signin->setStyleSheet(QString::fromUtf8("background:rgb(85, 255, 127)"));
        signup = new QPushButton(centralWidget);
        signup->setObjectName(QString::fromUtf8("signup"));
        signup->setGeometry(QRect(140, 200, 111, 41));
        QFont font3;
        font3.setFamily(QString::fromUtf8("B Sara"));
        font3.setPointSize(13);
        signup->setFont(font3);
        signup->setCursor(QCursor(Qt::PointingHandCursor));
        signup->setStyleSheet(QString::fromUtf8("background:rgb(85, 170, 255)"));
        error = new QLabel(centralWidget);
        error->setObjectName(QString::fromUtf8("error"));
        error->setGeometry(QRect(50, 250, 261, 20));
        error->setFont(font1);
        MainWindow->setCentralWidget(centralWidget);
        statusBar = new QStatusBar(MainWindow);
        statusBar->setObjectName(QString::fromUtf8("statusBar"));
        MainWindow->setStatusBar(statusBar);

        retranslateUi(MainWindow);

        QMetaObject::connectSlotsByName(MainWindow);
    } // setupUi

    void retranslateUi(QMainWindow *MainWindow)
    {
        MainWindow->setWindowTitle(QApplication::translate("MainWindow", "MainWindow", nullptr));
        titr->setText(QApplication::translate("MainWindow", "\331\206\330\261\331\205 \330\247\331\201\330\262\330\247\330\261 \330\254\330\247\331\205\330\271 \330\256\330\261\333\214\330\257 \331\210 \331\201\330\261\331\210\330\264 \330\247\331\205\331\204\330\247\332\251", nullptr));
        radioButtonm->setText(QApplication::translate("MainWindow", "\331\205\330\257\333\214\330\261 \330\250\331\206\332\257\330\247\331\207", nullptr));
        radioButtonu->setText(QApplication::translate("MainWindow", "\332\251\330\247\330\261\330\250\330\261 \331\205\330\271\331\205\331\210\331\204\333\214", nullptr));
        label->setText(QApplication::translate("MainWindow", "\330\250\331\207 \332\206\331\207 \330\271\331\206\331\210\330\247\331\206 \330\247\330\262 \330\250\330\261\331\206\330\247\331\205\331\207 \330\247\330\263\330\252\331\201\330\247\330\257\331\207 \331\205\333\214\332\251\331\206\333\214\330\257\330\237", nullptr));
        signin->setText(QApplication::translate("MainWindow", "\331\210\330\261\331\210\330\257", nullptr));
        signup->setText(QApplication::translate("MainWindow", "\330\253\330\250\330\252 \331\206\330\247\331\205", nullptr));
        error->setText(QString());
    } // retranslateUi

};

namespace Ui {
    class MainWindow: public Ui_MainWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINWINDOW_H
