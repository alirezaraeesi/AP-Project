#pragma once
#include "managersignin.h"
#include "ui_managersignin.h"
#include <iostream>
#include<string>
#include <fstream>
#include "managermentpanel.h"
using namespace std;
managerSignin::managerSignin(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::managerSignin)
{
    ui->setupUi(this);
}

managerSignin::~managerSignin()
{
    delete ui;
}

void managerSignin::on_signin_clicked()
{
    managermentPanel mp(ui->username->text());
    ifstream infile("managers/"+ui->username->text().toStdString());
    string password;
    if(infile.is_open() == 1)
    {
        infile>>password;
        if(ui->password->text().toStdString()==password)
        {
            mp.setname(ui->username->text());
            this->close();
            mp.exec();
        }
        else
        {
            ui->error->setText("<span style=\"color:red;\">نام کاربری یا رمز عبور ناصحیح است</span>");
        }
    }
    else
    {
        ui->error->setText("<span style=\"color:red;\">نام کاربری یا رمز عبور ناصحیح است</span>");
    }
}
