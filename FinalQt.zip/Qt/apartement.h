#pragma once
#include "house.h"
#include <vector>
#include "home.h"
class apartement :
	public house
{
	int numberfloor;
	bool lift;
	string photo;
	vector<home> h;
public:
	apartement();
	apartement(int areabuilt, int basscost, int numberfloor, string address, bool lift);
	void setareabuilt(int areabuilt);
	int getareabuilt();
	void setbasscost(int basscost);
	int getbasscost();
	void setaddress(string address);
	string getaddress();
	void setnumberfloor(int numberfloor);
	int getnumberfloor();
	void setlift(bool lift);
	bool getlift();
	void setPhoto(string _photo);
	string getPhoto();
	long long int computeTotalCost();
	long long int computeHomeCost(int,int);
	~apartement();
};

