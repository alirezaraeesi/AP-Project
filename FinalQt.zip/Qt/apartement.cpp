#include "apartement.h"



apartement::apartement()
{
	this->lift = 0;
	this->numberfloor = 0;
}

apartement::apartement(int areabuilt, int basscost, int numberfloor, string address, bool lift) :house(areabuilt, basscost, address)
{
	this->lift = lift;
	this->numberfloor = numberfloor;
}

void apartement::setareabuilt(int areabuilt)
{
	this->totalArea = areabuilt;
}

int apartement::getareabuilt()
{
	return totalArea;
}

void apartement::setbasscost(int basecost)
{
	this->baseCost = basecost;
}

int apartement::getbasscost()
{
	return baseCost;
}

void apartement::setaddress(string address)
{
	this->address = address;
}

string apartement::getaddress()
{
	return address;
}

void apartement::setnumberfloor(int numberfloor)
{
	this->numberfloor = numberfloor;
}

int apartement::getnumberfloor()
{
	return numberfloor;
}

void apartement::setlift(bool lift)
{
	this->lift = lift;
}

bool apartement::getlift()
{
	return lift;
}

void apartement::setPhoto(string _photo)
{
	photo = _photo;
}

string apartement::getPhoto()
{
	return photo;
}

long long int apartement::computeTotalCost()
{
	return (baseCost*totalArea)*0.8;
}

long long int apartement::computeHomeCost(int home,int use)
{
	auto p=	h.begin() + home;
	long long int a = p->getBuiltArea()*baseCost;
        a = a+p->getFloorNum() - 1 * 0.5;
        a = a+p->getRoomNum() - 1*0.8;
	if (lift)
	{
                a =a+(a* 0.2);
	}
	if (use == 0)
	{
                a =a+(a*0.5);
	}
	else if (use == 1)
	{
                a =a+(a*0.3);
	}
	return a;
}

apartement::~apartement()
{
}
