/********************************************************************************
** Form generated from reading UI file 'addnvilla.ui'
**
** Created by: Qt User Interface Compiler version 5.12.3
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_ADDNVILLA_H
#define UI_ADDNVILLA_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDialog>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_addNVilla
{
public:
    QPushButton *confirm;
    QLabel *error;
    QWidget *widget;
    QHBoxLayout *horizontalLayout;
    QVBoxLayout *verticalLayout_2;
    QLineEdit *builtarea;
    QLineEdit *frontyard;
    QLineEdit *backyard;
    QLineEdit *totalarea;
    QLineEdit *roomsnum;
    QLineEdit *photo;
    QLineEdit *basecost;
    QLineEdit *address;
    QVBoxLayout *verticalLayout;
    QLabel *label;
    QLabel *label_2;
    QLabel *label_3;
    QLabel *label_4;
    QLabel *label_5;
    QLabel *label_6;
    QLabel *label_7;
    QLabel *label_8;

    void setupUi(QDialog *addNVilla)
    {
        if (addNVilla->objectName().isEmpty())
            addNVilla->setObjectName(QString::fromUtf8("addNVilla"));
        addNVilla->resize(463, 459);
        confirm = new QPushButton(addNVilla);
        confirm->setObjectName(QString::fromUtf8("confirm"));
        confirm->setGeometry(QRect(190, 370, 91, 31));
        error = new QLabel(addNVilla);
        error->setObjectName(QString::fromUtf8("error"));
        error->setGeometry(QRect(140, 410, 201, 31));
        widget = new QWidget(addNVilla);
        widget->setObjectName(QString::fromUtf8("widget"));
        widget->setGeometry(QRect(90, 50, 271, 311));
        horizontalLayout = new QHBoxLayout(widget);
        horizontalLayout->setObjectName(QString::fromUtf8("horizontalLayout"));
        horizontalLayout->setContentsMargins(0, 0, 0, 0);
        verticalLayout_2 = new QVBoxLayout();
        verticalLayout_2->setObjectName(QString::fromUtf8("verticalLayout_2"));
        builtarea = new QLineEdit(widget);
        builtarea->setObjectName(QString::fromUtf8("builtarea"));

        verticalLayout_2->addWidget(builtarea);

        frontyard = new QLineEdit(widget);
        frontyard->setObjectName(QString::fromUtf8("frontyard"));

        verticalLayout_2->addWidget(frontyard);

        backyard = new QLineEdit(widget);
        backyard->setObjectName(QString::fromUtf8("backyard"));

        verticalLayout_2->addWidget(backyard);

        totalarea = new QLineEdit(widget);
        totalarea->setObjectName(QString::fromUtf8("totalarea"));

        verticalLayout_2->addWidget(totalarea);

        roomsnum = new QLineEdit(widget);
        roomsnum->setObjectName(QString::fromUtf8("roomsnum"));

        verticalLayout_2->addWidget(roomsnum);

        photo = new QLineEdit(widget);
        photo->setObjectName(QString::fromUtf8("photo"));

        verticalLayout_2->addWidget(photo);

        basecost = new QLineEdit(widget);
        basecost->setObjectName(QString::fromUtf8("basecost"));

        verticalLayout_2->addWidget(basecost);

        address = new QLineEdit(widget);
        address->setObjectName(QString::fromUtf8("address"));

        verticalLayout_2->addWidget(address);


        horizontalLayout->addLayout(verticalLayout_2);

        verticalLayout = new QVBoxLayout();
        verticalLayout->setObjectName(QString::fromUtf8("verticalLayout"));
        label = new QLabel(widget);
        label->setObjectName(QString::fromUtf8("label"));
        QFont font;
        font.setFamily(QString::fromUtf8("Nasim"));
        font.setPointSize(12);
        label->setFont(font);
        label->setLayoutDirection(Qt::RightToLeft);

        verticalLayout->addWidget(label);

        label_2 = new QLabel(widget);
        label_2->setObjectName(QString::fromUtf8("label_2"));
        label_2->setFont(font);
        label_2->setLayoutDirection(Qt::RightToLeft);

        verticalLayout->addWidget(label_2);

        label_3 = new QLabel(widget);
        label_3->setObjectName(QString::fromUtf8("label_3"));
        label_3->setFont(font);
        label_3->setLayoutDirection(Qt::RightToLeft);

        verticalLayout->addWidget(label_3);

        label_4 = new QLabel(widget);
        label_4->setObjectName(QString::fromUtf8("label_4"));
        label_4->setFont(font);
        label_4->setLayoutDirection(Qt::RightToLeft);

        verticalLayout->addWidget(label_4);

        label_5 = new QLabel(widget);
        label_5->setObjectName(QString::fromUtf8("label_5"));
        label_5->setFont(font);
        label_5->setLayoutDirection(Qt::RightToLeft);

        verticalLayout->addWidget(label_5);

        label_6 = new QLabel(widget);
        label_6->setObjectName(QString::fromUtf8("label_6"));
        label_6->setFont(font);
        label_6->setLayoutDirection(Qt::RightToLeft);

        verticalLayout->addWidget(label_6);

        label_7 = new QLabel(widget);
        label_7->setObjectName(QString::fromUtf8("label_7"));
        label_7->setFont(font);
        label_7->setLayoutDirection(Qt::RightToLeft);

        verticalLayout->addWidget(label_7);

        label_8 = new QLabel(widget);
        label_8->setObjectName(QString::fromUtf8("label_8"));
        label_8->setFont(font);
        label_8->setLayoutDirection(Qt::RightToLeft);

        verticalLayout->addWidget(label_8);


        horizontalLayout->addLayout(verticalLayout);


        retranslateUi(addNVilla);

        QMetaObject::connectSlotsByName(addNVilla);
    } // setupUi

    void retranslateUi(QDialog *addNVilla)
    {
        addNVilla->setWindowTitle(QApplication::translate("addNVilla", "Dialog", nullptr));
        confirm->setText(QApplication::translate("addNVilla", "\330\252\330\243\333\214\333\214\330\257", nullptr));
        error->setText(QString());
        label->setText(QApplication::translate("addNVilla", "\331\205\330\263\330\247\330\255\330\252 \330\263\330\247\330\256\330\252:", nullptr));
        label_2->setText(QApplication::translate("addNVilla", "\331\205\330\263\330\247\330\255\330\252 \330\255\333\214\330\247\330\267 \330\254\331\204\331\210\333\214\333\214:", nullptr));
        label_3->setText(QApplication::translate("addNVilla", "\331\205\330\263\330\247\330\255\330\252 \330\255\333\214\330\247\330\267 \330\271\331\202\330\250\333\214:", nullptr));
        label_4->setText(QApplication::translate("addNVilla", "\331\205\330\263\330\247\330\255\330\252 \332\251\331\204:", nullptr));
        label_5->setText(QApplication::translate("addNVilla", "\330\252\330\271\330\257\330\247\330\257 \330\247\330\252\330\247\331\202:", nullptr));
        label_6->setText(QApplication::translate("addNVilla", "\330\271\332\251\330\263 \331\205\330\263\332\251\331\206:", nullptr));
        label_7->setText(QApplication::translate("addNVilla", "\331\202\333\214\331\205\330\252 \331\276\330\247\333\214\331\207:", nullptr));
        label_8->setText(QApplication::translate("addNVilla", "\330\242\330\257\330\261\330\263:", nullptr));
    } // retranslateUi

};

namespace Ui {
    class addNVilla: public Ui_addNVilla {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_ADDNVILLA_H
