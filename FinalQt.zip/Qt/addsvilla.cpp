#include "addsvilla.h"
#include "ui_addsvilla.h"
#include "south.cpp"
#include <vector>
#include <iostream>
#include <fstream>
using namespace std;
addSVilla::addSVilla(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::addSVilla)
{
    ui->setupUi(this);
}

addSVilla::~addSVilla()
{
    delete ui;
}

void addSVilla::on_confirm_clicked()
{
    south s;
    vector<south>south;
    s.setareabuilt(ui->builtarea->text().toInt());
    s.setareayard(ui->yard->text().toInt());
    s.setParkingArea(ui->parking->text().toInt());
    s.setTotalArea(ui->totalarea->text().toInt());
    s.setnumrooms(ui->roomsnum->text().toInt());
    s.setPhoto(ui->photo->text().toStdString());
    s.setbasscost(ui->basecost->text().toInt());
    s.setaddress(ui->address->text().toStdString());
    south.push_back(s);
    ofstream myfile("villa/svilla",ios::app);
    if (myfile.is_open() == false)
        ui->error->setText("<span style=\"color:red;\">ویلای مورد نظر ثبت نشد</span>");
    else
    {
        myfile <<ui->builtarea->text().toInt()<<" "<<ui->yard->text().toInt()<< " " << ui->parking->text().toInt() << " " << ui->totalarea->text().toInt() <<" "<<ui->roomsnum->text().toInt()<<" "<<ui->photo->text().toStdString()<<" "<< ui->basecost->text().toInt()<<" "<< ui->address->text().toStdString()<<endl;
        myfile.close();
        ui->error->setText("<span style=\"color:green;\">ویلای مورد نظر ثبت شد</span>");
    }
}
