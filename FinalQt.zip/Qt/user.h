#pragma once
#include <iostream>
using namespace std;
class user
{
	string fname;
	string lname;
	string birthday;
	bool usercondition;
	string username;
	string password;
	double stock;
	string timelogout;
	string timeinput;
public:
	user();
	user(string fname,string lname, string birthday, string username, string password);
	void setfname(string name);
	string getfname();
	void setlname(string name);
	string getlname();
	void setusername(string username);
	string getusername();
	void setpassword(string password);
	string getpassword();
	void setbirthday(string birthday);
	string getbirthday();
	void settimelogout(string timelogout);
	string gettimelogout();
	void settimeinput(string timeinput);
	string gettimeinput();
	~user();
};

