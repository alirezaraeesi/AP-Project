#pragma once
#include <iostream>
using namespace std;
class home
{
	int floorNum;
	int roomsNum;
	int builtArea;
	string photo;
public:
	home();
	home(int, int, int, string);
	void setFloorNum(int);
	int getFloorNum();
	void setRoomsNum(int);
	int getRoomNum();
	void setBuiltArea(int);
	int getBuiltArea();
	void setPhoto(string);
	string getPhoto();
	~home();
};

