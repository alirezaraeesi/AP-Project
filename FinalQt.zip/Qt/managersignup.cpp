#include "managersignup.h"
#include "ui_managersignup.h"
#include "mainwindow.h"
#include <iostream>
#include <fstream>
#include "boardmanager.cpp"
using namespace std;
managerSignup::managerSignup(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::managerSignup)
{
    ui->setupUi(this);
    //QColor col=QColor(Qt::green);
    //QString qss=QString("background-color:%1").arg(col.name());
    //ui->confirm->setStyleSheet(qss);
}

managerSignup::~managerSignup()
{
    delete ui;
}

void managerSignup::on_confirm_clicked()
{
    boardmanager bm;
    ifstream infile("managers/"+ui->username->text().toStdString());
    if(ui->fname->text()==nullptr || ui->lname->text()==nullptr || ui->username->text()==nullptr || ui->password->text()==nullptr || ui->repassword->text()==nullptr)
    {
        ui->error->setText("<span style=\"color:red;\">لطفا تمامی فیلد ها را پر کرده و تاریخ تولدتان را مشخص کنید</span>");
    }
    else
    {
        if(ui->password->text()==ui->repassword->text() && infile.is_open() == false)
        {
            bm.setpassword(ui->password->text().toStdString());
            bm.setusername(ui->username->text().toStdString());
            bm.setbirthday(ui->birthday->selectedDate().toString().toStdString());
            bm.setfname(ui->fname->text().toStdString());
            bm.setlname(ui->lname->text().toStdString());
            ofstream myfile("managers/"+ui->username->text().toStdString(),ios::app);
            if (myfile.is_open() == false)
                ui->error->setText("<span style=\"color:red;\">حساب مورد نظر ساخته نشد</span>");
            else
            {
                myfile <<ui->password->text().toStdString()<<endl<< ui->fname->text().toStdString() << " " << ui->lname->text().toStdString() << endl << ui->birthday->selectedDate().toString().toStdString() <<endl<<"0"<<endl<<"1";
                myfile.close();
                ui->error->setText("<span style=\"color:green;\">حساب مورد نظر ساخته شد</span>");
            }
        }
        else
        {
            ui->error->setText("<span style=\"color:red;>تکرار رمز عبور شما با رمز عبورتان یکسان نیست</span>");
        }
    }
}
