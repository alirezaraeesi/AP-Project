#ifndef USERSIGNUP_H
#define USERSIGNUP_H

#include <QDialog>

namespace Ui {
class userSignup;
}

class userSignup : public QDialog
{
    Q_OBJECT

public:
    explicit userSignup(QWidget *parent = nullptr);
    ~userSignup();

private slots:
    void on_confirm_clicked();

private:
    Ui::userSignup *ui;
};

#endif // USERSIGNUP_H
