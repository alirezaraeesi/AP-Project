/********************************************************************************
** Form generated from reading UI file 'observeall.ui'
**
** Created by: Qt User Interface Compiler version 5.12.3
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_OBSERVEALL_H
#define UI_OBSERVEALL_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QCheckBox>
#include <QtWidgets/QDialog>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QTextEdit>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_observeall
{
public:
    QLabel *label_4;
    QTextEdit *textEdit;
    QWidget *widget;
    QVBoxLayout *verticalLayout_3;
    QHBoxLayout *horizontalLayout;
    QVBoxLayout *verticalLayout_2;
    QLineEdit *price;
    QLineEdit *builtarea;
    QLineEdit *street;
    QVBoxLayout *verticalLayout;
    QLabel *label;
    QLabel *label_2;
    QLabel *label_3;
    QHBoxLayout *horizontalLayout_2;
    QPushButton *pushButton;
    QCheckBox *sort;

    void setupUi(QDialog *observeall)
    {
        if (observeall->objectName().isEmpty())
            observeall->setObjectName(QString::fromUtf8("observeall"));
        observeall->resize(494, 699);
        label_4 = new QLabel(observeall);
        label_4->setObjectName(QString::fromUtf8("label_4"));
        label_4->setGeometry(QRect(140, 10, 191, 41));
        QFont font;
        font.setFamily(QString::fromUtf8("Nasim"));
        font.setPointSize(12);
        label_4->setFont(font);
        textEdit = new QTextEdit(observeall);
        textEdit->setObjectName(QString::fromUtf8("textEdit"));
        textEdit->setGeometry(QRect(80, 200, 311, 471));
        widget = new QWidget(observeall);
        widget->setObjectName(QString::fromUtf8("widget"));
        widget->setGeometry(QRect(121, 52, 235, 130));
        verticalLayout_3 = new QVBoxLayout(widget);
        verticalLayout_3->setObjectName(QString::fromUtf8("verticalLayout_3"));
        verticalLayout_3->setContentsMargins(0, 0, 0, 0);
        horizontalLayout = new QHBoxLayout();
        horizontalLayout->setObjectName(QString::fromUtf8("horizontalLayout"));
        verticalLayout_2 = new QVBoxLayout();
        verticalLayout_2->setObjectName(QString::fromUtf8("verticalLayout_2"));
        price = new QLineEdit(widget);
        price->setObjectName(QString::fromUtf8("price"));

        verticalLayout_2->addWidget(price);

        builtarea = new QLineEdit(widget);
        builtarea->setObjectName(QString::fromUtf8("builtarea"));

        verticalLayout_2->addWidget(builtarea);

        street = new QLineEdit(widget);
        street->setObjectName(QString::fromUtf8("street"));

        verticalLayout_2->addWidget(street);


        horizontalLayout->addLayout(verticalLayout_2);

        verticalLayout = new QVBoxLayout();
        verticalLayout->setObjectName(QString::fromUtf8("verticalLayout"));
        label = new QLabel(widget);
        label->setObjectName(QString::fromUtf8("label"));
        label->setFont(font);

        verticalLayout->addWidget(label);

        label_2 = new QLabel(widget);
        label_2->setObjectName(QString::fromUtf8("label_2"));
        label_2->setFont(font);

        verticalLayout->addWidget(label_2);

        label_3 = new QLabel(widget);
        label_3->setObjectName(QString::fromUtf8("label_3"));
        label_3->setFont(font);

        verticalLayout->addWidget(label_3);


        horizontalLayout->addLayout(verticalLayout);


        verticalLayout_3->addLayout(horizontalLayout);

        horizontalLayout_2 = new QHBoxLayout();
        horizontalLayout_2->setObjectName(QString::fromUtf8("horizontalLayout_2"));
        pushButton = new QPushButton(widget);
        pushButton->setObjectName(QString::fromUtf8("pushButton"));

        horizontalLayout_2->addWidget(pushButton);

        sort = new QCheckBox(widget);
        sort->setObjectName(QString::fromUtf8("sort"));
        sort->setFont(font);
        sort->setLayoutDirection(Qt::RightToLeft);

        horizontalLayout_2->addWidget(sort);


        verticalLayout_3->addLayout(horizontalLayout_2);


        retranslateUi(observeall);

        QMetaObject::connectSlotsByName(observeall);
    } // setupUi

    void retranslateUi(QDialog *observeall)
    {
        observeall->setWindowTitle(QApplication::translate("observeall", "Dialog", nullptr));
        label_4->setText(QApplication::translate("observeall", "\331\204\330\267\331\201\330\247 \331\201\333\214\331\204\330\252\330\261 \331\207\330\247\333\214 \331\205\331\210\330\261\330\257 \331\206\330\270\330\261\330\252\330\247\331\206 \330\261\330\247 \330\252\330\271\333\214\333\214\331\206 \332\251\331\206\333\214\330\257", nullptr));
        label->setText(QApplication::translate("observeall", "\330\255\330\257\330\247\332\251\330\253\330\261 \331\202\333\214\331\205\330\252:", nullptr));
        label_2->setText(QApplication::translate("observeall", "\330\255\330\257\330\247\331\202\331\204 \331\205\330\252\330\261\330\247\332\230 \330\263\330\247\330\256\330\252:", nullptr));
        label_3->setText(QApplication::translate("observeall", "\331\206\330\247\331\205 \330\256\333\214\330\247\330\250\330\247\331\206:", nullptr));
        pushButton->setText(QApplication::translate("observeall", "\330\247\330\271\331\205\330\247\331\204", nullptr));
        sort->setText(QApplication::translate("observeall", "\330\250\331\207 \330\252\330\261\330\252\333\214\330\250 \331\202\333\214\331\205\330\252", nullptr));
    } // retranslateUi

};

namespace Ui {
    class observeall: public Ui_observeall {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_OBSERVEALL_H
