/********************************************************************************
** Form generated from reading UI file 'seeapartement.ui'
**
** Created by: Qt User Interface Compiler version 5.12.3
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_SEEAPARTEMENT_H
#define UI_SEEAPARTEMENT_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDialog>
#include <QtWidgets/QLabel>
#include <QtWidgets/QTextEdit>

QT_BEGIN_NAMESPACE

class Ui_seeapartement
{
public:
    QLabel *error;
    QTextEdit *textEdit;

    void setupUi(QDialog *seeapartement)
    {
        if (seeapartement->objectName().isEmpty())
            seeapartement->setObjectName(QString::fromUtf8("seeapartement"));
        seeapartement->resize(590, 486);
        error = new QLabel(seeapartement);
        error->setObjectName(QString::fromUtf8("error"));
        error->setGeometry(QRect(70, 260, 47, 13));
        textEdit = new QTextEdit(seeapartement);
        textEdit->setObjectName(QString::fromUtf8("textEdit"));
        textEdit->setGeometry(QRect(140, 10, 281, 471));

        retranslateUi(seeapartement);

        QMetaObject::connectSlotsByName(seeapartement);
    } // setupUi

    void retranslateUi(QDialog *seeapartement)
    {
        seeapartement->setWindowTitle(QApplication::translate("seeapartement", "Dialog", nullptr));
        error->setText(QApplication::translate("seeapartement", "TextLabel", nullptr));
    } // retranslateUi

};

namespace Ui {
    class seeapartement: public Ui_seeapartement {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_SEEAPARTEMENT_H
