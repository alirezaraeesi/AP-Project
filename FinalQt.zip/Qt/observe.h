#ifndef OBSERVE_H
#define OBSERVE_H

#include <QDialog>

namespace Ui {
class observe;
}

class observe : public QDialog
{
    Q_OBJECT

public:
    explicit observe(QWidget *parent = nullptr);
    ~observe();

private slots:
    void on_ok_clicked();

private:
    Ui::observe *ui;
};

#endif // OBSERVE_H
