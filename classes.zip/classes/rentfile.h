﻿#pragma once
#include "file.h"
class rentfile :
	public file
{
	int renttime;
	int mr1;//mr1=میزان رهن
	int mrent1;//mrent1=میزان اجاره
public:
	rentfile();
	rentfile(villa* obj, int commission, int renttime);
	long long int  totalcost();
	int getrenttime();
	int getmr1();
	int getmrent1();
	~rentfile();
};

