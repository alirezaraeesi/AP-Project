#ifndef OBSERVEAPARTEMENT_H
#define OBSERVEAPARTEMENT_H

#include <QDialog>

namespace Ui {
class observeapartement;
}

class observeapartement : public QDialog
{
    Q_OBJECT

public:
    explicit observeapartement(QWidget *parent = nullptr);
    ~observeapartement();

private:
    Ui::observeapartement *ui;
};

#endif // OBSERVEAPARTEMENT_H
