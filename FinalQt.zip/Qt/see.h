#ifndef SEE_H
#define SEE_H

#include <QDialog>

namespace Ui {
class see;
}

class see : public QDialog
{
    Q_OBJECT

public:
    explicit see(QWidget *parent = nullptr);
    ~see();

private slots:
    void on_ok_clicked();

private:
    Ui::see *ui;
};

#endif // SEE_H
