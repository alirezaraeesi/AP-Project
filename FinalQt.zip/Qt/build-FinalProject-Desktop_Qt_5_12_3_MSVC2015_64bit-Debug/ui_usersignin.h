/********************************************************************************
** Form generated from reading UI file 'usersignin.ui'
**
** Created by: Qt User Interface Compiler version 5.12.3
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_USERSIGNIN_H
#define UI_USERSIGNIN_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDialog>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_userSignin
{
public:
    QPushButton *pushButton;
    QLabel *error;
    QWidget *layoutWidget;
    QVBoxLayout *verticalLayout_3;
    QHBoxLayout *horizontalLayout;
    QVBoxLayout *verticalLayout_2;
    QLineEdit *username;
    QLineEdit *password;
    QVBoxLayout *verticalLayout;
    QLabel *label;
    QLabel *label_2;
    QPushButton *signin;

    void setupUi(QDialog *userSignin)
    {
        if (userSignin->objectName().isEmpty())
            userSignin->setObjectName(QString::fromUtf8("userSignin"));
        userSignin->resize(400, 300);
        userSignin->setMaximumSize(QSize(400, 300));
        pushButton = new QPushButton(userSignin);
        pushButton->setObjectName(QString::fromUtf8("pushButton"));
        pushButton->setGeometry(QRect(20, 260, 61, 21));
        QFont font;
        font.setFamily(QString::fromUtf8("B Sara"));
        pushButton->setFont(font);
        error = new QLabel(userSignin);
        error->setObjectName(QString::fromUtf8("error"));
        error->setGeometry(QRect(90, 200, 201, 21));
        QFont font1;
        font1.setFamily(QString::fromUtf8("Nasim"));
        font1.setPointSize(8);
        error->setFont(font1);
        layoutWidget = new QWidget(userSignin);
        layoutWidget->setObjectName(QString::fromUtf8("layoutWidget"));
        layoutWidget->setGeometry(QRect(90, 90, 196, 97));
        verticalLayout_3 = new QVBoxLayout(layoutWidget);
        verticalLayout_3->setObjectName(QString::fromUtf8("verticalLayout_3"));
        verticalLayout_3->setContentsMargins(0, 0, 0, 0);
        horizontalLayout = new QHBoxLayout();
        horizontalLayout->setObjectName(QString::fromUtf8("horizontalLayout"));
        verticalLayout_2 = new QVBoxLayout();
        verticalLayout_2->setObjectName(QString::fromUtf8("verticalLayout_2"));
        username = new QLineEdit(layoutWidget);
        username->setObjectName(QString::fromUtf8("username"));

        verticalLayout_2->addWidget(username);

        password = new QLineEdit(layoutWidget);
        password->setObjectName(QString::fromUtf8("password"));
        password->setCursor(QCursor(Qt::IBeamCursor));
        password->setEchoMode(QLineEdit::Password);

        verticalLayout_2->addWidget(password);


        horizontalLayout->addLayout(verticalLayout_2);

        verticalLayout = new QVBoxLayout();
        verticalLayout->setObjectName(QString::fromUtf8("verticalLayout"));
        label = new QLabel(layoutWidget);
        label->setObjectName(QString::fromUtf8("label"));
        QFont font2;
        font2.setFamily(QString::fromUtf8("Nasim"));
        font2.setPointSize(12);
        label->setFont(font2);

        verticalLayout->addWidget(label);

        label_2 = new QLabel(layoutWidget);
        label_2->setObjectName(QString::fromUtf8("label_2"));
        label_2->setFont(font2);

        verticalLayout->addWidget(label_2);


        horizontalLayout->addLayout(verticalLayout);


        verticalLayout_3->addLayout(horizontalLayout);

        signin = new QPushButton(layoutWidget);
        signin->setObjectName(QString::fromUtf8("signin"));
        QFont font3;
        font3.setFamily(QString::fromUtf8("B Sara"));
        font3.setPointSize(10);
        signin->setFont(font3);
        signin->setStyleSheet(QString::fromUtf8("background:rgb(85, 255, 127)"));

        verticalLayout_3->addWidget(signin);


        retranslateUi(userSignin);

        QMetaObject::connectSlotsByName(userSignin);
    } // setupUi

    void retranslateUi(QDialog *userSignin)
    {
        userSignin->setWindowTitle(QApplication::translate("userSignin", "Dialog", nullptr));
        pushButton->setText(QApplication::translate("userSignin", "\330\250\330\247\330\262\332\257\330\264\330\252", nullptr));
        error->setText(QString());
        label->setText(QApplication::translate("userSignin", "\331\206\330\247\331\205 \332\251\330\247\330\261\330\250\330\261\333\214:", nullptr));
        label_2->setText(QApplication::translate("userSignin", "\330\261\331\205\330\262 \330\271\330\250\331\210\330\261:", nullptr));
        signin->setText(QApplication::translate("userSignin", "\331\210\330\261\331\210\330\257", nullptr));
    } // retranslateUi

};

namespace Ui {
    class userSignin: public Ui_userSignin {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_USERSIGNIN_H
