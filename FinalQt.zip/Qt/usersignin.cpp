#include "usersignin.h"
#include "ui_usersignin.h"
#include "usermentpanel.h"
#include <iostream>
#include <fstream>
using namespace std;


userSignin::userSignin(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::userSignin)
{
    ui->setupUi(this);
}

userSignin::~userSignin()
{
    delete ui;
}

void userSignin::on_signin_clicked()
{
    usermentPanel up;
    ifstream infile("users/"+ui->username->text().toStdString());
    string password;
    if(infile.is_open() == 1)
    {
        infile>>password;
        if(ui->password->text().toStdString()==password)
        {
            //up.setname(ui->username->text());
            this->close();
            up.exec();
        }
        else
        {
            ui->error->setText("<span style=\"color:red;\">نام کاربری یا رمز عبور ناصحیح است</span>");
        }
    }
    else
    {
        ui->error->setText("<span style=\"color:red;\">نام کاربری یا رمز عبور ناصحیح است</span>");
    }
}
