#include "boardmanager.h"



boardmanager::boardmanager()
{
}


boardmanager::~boardmanager()
{
}
