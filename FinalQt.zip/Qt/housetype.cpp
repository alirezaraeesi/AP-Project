#include "housetype.h"
#include "ui_housetype.h"
#include "addapartement.h"
#include "addnvilla.h"
#include "addsvilla.h"
houseType::houseType(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::houseType)
{
    ui->setupUi(this);
}

houseType::~houseType()
{
    delete ui;
}

void houseType::on_ok_clicked()
{
    addNVilla nv;
    addSVilla sv;
    addApartement a;
    if(ui->nvilla->isChecked())
    {
        nv.exec();
    }
    else if(ui->svilla->isChecked())
    {
        sv.exec();
    }
    else if(ui->apatement->isChecked())
    {
        a.exec();
    }
}
