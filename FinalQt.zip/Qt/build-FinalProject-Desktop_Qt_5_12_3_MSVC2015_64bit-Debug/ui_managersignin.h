/********************************************************************************
** Form generated from reading UI file 'managersignin.ui'
**
** Created by: Qt User Interface Compiler version 5.12.3
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MANAGERSIGNIN_H
#define UI_MANAGERSIGNIN_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDialog>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_managerSignin
{
public:
    QWidget *layoutWidget;
    QVBoxLayout *verticalLayout_3;
    QHBoxLayout *horizontalLayout;
    QVBoxLayout *verticalLayout_2;
    QLineEdit *username;
    QLineEdit *password;
    QVBoxLayout *verticalLayout;
    QLabel *label;
    QLabel *label_2;
    QPushButton *signin;
    QLabel *error;

    void setupUi(QDialog *managerSignin)
    {
        if (managerSignin->objectName().isEmpty())
            managerSignin->setObjectName(QString::fromUtf8("managerSignin"));
        managerSignin->resize(400, 300);
        layoutWidget = new QWidget(managerSignin);
        layoutWidget->setObjectName(QString::fromUtf8("layoutWidget"));
        layoutWidget->setGeometry(QRect(90, 90, 196, 97));
        verticalLayout_3 = new QVBoxLayout(layoutWidget);
        verticalLayout_3->setObjectName(QString::fromUtf8("verticalLayout_3"));
        verticalLayout_3->setContentsMargins(0, 0, 0, 0);
        horizontalLayout = new QHBoxLayout();
        horizontalLayout->setObjectName(QString::fromUtf8("horizontalLayout"));
        verticalLayout_2 = new QVBoxLayout();
        verticalLayout_2->setObjectName(QString::fromUtf8("verticalLayout_2"));
        username = new QLineEdit(layoutWidget);
        username->setObjectName(QString::fromUtf8("username"));

        verticalLayout_2->addWidget(username);

        password = new QLineEdit(layoutWidget);
        password->setObjectName(QString::fromUtf8("password"));
        QFont font;
        font.setFamily(QString::fromUtf8("MS Shell Dlg 2"));
        password->setFont(font);
        password->setEchoMode(QLineEdit::Password);

        verticalLayout_2->addWidget(password);


        horizontalLayout->addLayout(verticalLayout_2);

        verticalLayout = new QVBoxLayout();
        verticalLayout->setObjectName(QString::fromUtf8("verticalLayout"));
        label = new QLabel(layoutWidget);
        label->setObjectName(QString::fromUtf8("label"));
        QFont font1;
        font1.setFamily(QString::fromUtf8("Nasim"));
        font1.setPointSize(12);
        label->setFont(font1);

        verticalLayout->addWidget(label);

        label_2 = new QLabel(layoutWidget);
        label_2->setObjectName(QString::fromUtf8("label_2"));
        label_2->setFont(font1);

        verticalLayout->addWidget(label_2);


        horizontalLayout->addLayout(verticalLayout);


        verticalLayout_3->addLayout(horizontalLayout);

        signin = new QPushButton(layoutWidget);
        signin->setObjectName(QString::fromUtf8("signin"));
        QFont font2;
        font2.setFamily(QString::fromUtf8("B Sara"));
        font2.setPointSize(10);
        signin->setFont(font2);
        signin->setStyleSheet(QString::fromUtf8("background:rgb(85, 255, 127)"));

        verticalLayout_3->addWidget(signin);

        error = new QLabel(managerSignin);
        error->setObjectName(QString::fromUtf8("error"));
        error->setGeometry(QRect(40, 200, 221, 31));
        QFont font3;
        font3.setFamily(QString::fromUtf8("Nasim"));
        error->setFont(font3);
        error->setLayoutDirection(Qt::RightToLeft);

        retranslateUi(managerSignin);

        QMetaObject::connectSlotsByName(managerSignin);
    } // setupUi

    void retranslateUi(QDialog *managerSignin)
    {
        managerSignin->setWindowTitle(QApplication::translate("managerSignin", "Dialog", nullptr));
        label->setText(QApplication::translate("managerSignin", "\331\206\330\247\331\205 \332\251\330\247\330\261\330\250\330\261\333\214:", nullptr));
        label_2->setText(QApplication::translate("managerSignin", "\330\261\331\205\330\262 \330\271\330\250\331\210\330\261:", nullptr));
        signin->setText(QApplication::translate("managerSignin", "\331\210\330\261\331\210\330\257", nullptr));
        error->setText(QString());
    } // retranslateUi

};

namespace Ui {
    class managerSignin: public Ui_managerSignin {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MANAGERSIGNIN_H
