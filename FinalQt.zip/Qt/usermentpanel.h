#ifndef USERMENTPANEL_H
#define USERMENTPANEL_H

#include <QDialog>

namespace Ui {
class usermentPanel;
}

class usermentPanel : public QDialog
{
    Q_OBJECT

public:
    explicit usermentPanel(QWidget *parent = nullptr);
    ~usermentPanel();

private slots:
    void on_pushButton_5_clicked();

private:
    Ui::usermentPanel *ui;
};

#endif // USERMENTPANEL_H
