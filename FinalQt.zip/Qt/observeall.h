#ifndef OBSERVEALL_H
#define OBSERVEALL_H

#include <QDialog>

namespace Ui {
class observeall;
}

class observeall : public QDialog
{
    Q_OBJECT

public:
    explicit observeall(QWidget *parent = nullptr);
    ~observeall();

private slots:
    void on_pushButton_clicked();

private:
    Ui::observeall *ui;
};

#endif // OBSERVEALL_H
