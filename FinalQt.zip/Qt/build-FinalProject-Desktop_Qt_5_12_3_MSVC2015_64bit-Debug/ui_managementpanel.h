/********************************************************************************
** Form generated from reading UI file 'managementpanel.ui'
**
** Created by: Qt User Interface Compiler version 5.12.3
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MANAGEMENTPANEL_H
#define UI_MANAGEMENTPANEL_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_managementPanel
{
public:

    void setupUi(QWidget *managementPanel)
    {
        if (managementPanel->objectName().isEmpty())
            managementPanel->setObjectName(QString::fromUtf8("managementPanel"));
        managementPanel->resize(400, 300);

        retranslateUi(managementPanel);

        QMetaObject::connectSlotsByName(managementPanel);
    } // setupUi

    void retranslateUi(QWidget *managementPanel)
    {
        managementPanel->setWindowTitle(QApplication::translate("managementPanel", "Form", nullptr));
    } // retranslateUi

};

namespace Ui {
    class managementPanel: public Ui_managementPanel {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MANAGEMENTPANEL_H
