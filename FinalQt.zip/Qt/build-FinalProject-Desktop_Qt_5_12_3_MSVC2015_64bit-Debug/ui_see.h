/********************************************************************************
** Form generated from reading UI file 'see.ui'
**
** Created by: Qt User Interface Compiler version 5.12.3
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_SEE_H
#define UI_SEE_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDialog>
#include <QtWidgets/QLabel>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QRadioButton>

QT_BEGIN_NAMESPACE

class Ui_see
{
public:
    QPushButton *ok;
    QRadioButton *nvilla;
    QRadioButton *apatement;
    QRadioButton *svilla;
    QLabel *label;

    void setupUi(QDialog *see)
    {
        if (see->objectName().isEmpty())
            see->setObjectName(QString::fromUtf8("see"));
        see->resize(347, 219);
        ok = new QPushButton(see);
        ok->setObjectName(QString::fromUtf8("ok"));
        ok->setGeometry(QRect(129, 160, 81, 23));
        nvilla = new QRadioButton(see);
        nvilla->setObjectName(QString::fromUtf8("nvilla"));
        nvilla->setGeometry(QRect(120, 60, 91, 21));
        QFont font;
        font.setFamily(QString::fromUtf8("Nasim"));
        font.setPointSize(12);
        nvilla->setFont(font);
        nvilla->setLayoutDirection(Qt::RightToLeft);
        apatement = new QRadioButton(see);
        apatement->setObjectName(QString::fromUtf8("apatement"));
        apatement->setGeometry(QRect(120, 120, 91, 21));
        apatement->setFont(font);
        apatement->setLayoutDirection(Qt::RightToLeft);
        svilla = new QRadioButton(see);
        svilla->setObjectName(QString::fromUtf8("svilla"));
        svilla->setGeometry(QRect(120, 90, 91, 21));
        svilla->setFont(font);
        svilla->setLayoutDirection(Qt::RightToLeft);
        label = new QLabel(see);
        label->setObjectName(QString::fromUtf8("label"));
        label->setGeometry(QRect(5, 15, 231, 31));
        label->setFont(font);
        label->setLayoutDirection(Qt::RightToLeft);

        retranslateUi(see);

        QMetaObject::connectSlotsByName(see);
    } // setupUi

    void retranslateUi(QDialog *see)
    {
        see->setWindowTitle(QApplication::translate("see", "Dialog", nullptr));
        ok->setText(QApplication::translate("see", "\330\252\330\243\333\214\333\214\330\257", nullptr));
        nvilla->setText(QApplication::translate("see", "\331\210\333\214\331\204\330\247\333\214\333\214 \330\264\331\205\330\247\331\204\333\214", nullptr));
        apatement->setText(QApplication::translate("see", "\330\242\331\276\330\247\330\261\330\252\331\205\330\247\331\206", nullptr));
        svilla->setText(QApplication::translate("see", "\331\210\333\214\331\204\330\247\333\214\333\214 \330\254\331\206\331\210\330\250\333\214", nullptr));
        label->setText(QApplication::translate("see", "\331\204\330\267\331\201\330\247 \331\206\331\210\330\271 \331\205\330\263\332\251\331\206 \330\261\330\247 \330\247\331\206\330\252\330\256\330\247\330\250 \332\251\331\206\333\214\330\257.", nullptr));
    } // retranslateUi

};

namespace Ui {
    class see: public Ui_see {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_SEE_H
