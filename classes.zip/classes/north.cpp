#include "north.h"



north::north()
{
	backYardArea = 0;
	frontYardArea = 0;
}

north::north(int _builtArea, int _frontYardArea, int _backYardArea, int _totalArea, int _roomsNum, string _photo, int _baseCost, string _address): villa(_totalArea,_builtArea,_baseCost,_roomsNum,_address,_photo)
{
	frontYardArea = _frontYardArea;
	backYardArea = _backYardArea;
}

void north::setBackYard(int _backYardArea)
{
	backYardArea = _backYardArea;
}

int north::getBackYard()
{
	return backYardArea;
}

void north::setFrontYardArea(int _frontYardArea)
{
	frontYardArea = _frontYardArea;
}

int north::getFrontYardArea()
{
	return frontYardArea;
}

long long int north::computetotalcost()
{
	return baseCost*builtArea + (baseCost*frontYardArea*0.3) + (baseCost*backYardArea*0.15);
}

north::~north()
{
}
