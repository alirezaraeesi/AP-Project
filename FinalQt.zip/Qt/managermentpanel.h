#ifndef MANAGERMENTPANEL_H
#define MANAGERMENTPANEL_H

#include <QDialog>
#include<iostream>
#include<QString>
using namespace std;
namespace Ui {
class managermentPanel;
}

class managermentPanel : public QDialog
{
    Q_OBJECT

public:
    explicit managermentPanel(QString,QWidget *parent = nullptr);
    ~managermentPanel();
   void setname(QString name);
   QString getname();

private slots:

   void on_addhouse_clicked();

   void on_pushButton_5_clicked();

private:
    Ui::managermentPanel *ui;
    QString name;
};

#endif // MANAGERMENTPANEL_H
