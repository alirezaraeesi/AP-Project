/********************************************************************************
** Form generated from reading UI file 'usermentpanel.ui'
**
** Created by: Qt User Interface Compiler version 5.12.3
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_USERMENTPANEL_H
#define UI_USERMENTPANEL_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDialog>
#include <QtWidgets/QLabel>
#include <QtWidgets/QPushButton>

QT_BEGIN_NAMESPACE

class Ui_usermentPanel
{
public:
    QLabel *hi;
    QPushButton *addhouse;
    QLabel *label_2;
    QPushButton *pushButton_5;
    QPushButton *pushButton_6;

    void setupUi(QDialog *usermentPanel)
    {
        if (usermentPanel->objectName().isEmpty())
            usermentPanel->setObjectName(QString::fromUtf8("usermentPanel"));
        usermentPanel->resize(425, 311);
        hi = new QLabel(usermentPanel);
        hi->setObjectName(QString::fromUtf8("hi"));
        hi->setGeometry(QRect(140, 40, 231, 31));
        QFont font;
        font.setFamily(QString::fromUtf8("Nasim"));
        font.setPointSize(12);
        hi->setFont(font);
        hi->setLayoutDirection(Qt::RightToLeft);
        addhouse = new QPushButton(usermentPanel);
        addhouse->setObjectName(QString::fromUtf8("addhouse"));
        addhouse->setGeometry(QRect(210, 110, 161, 61));
        QFont font1;
        font1.setFamily(QString::fromUtf8("B Sara"));
        font1.setPointSize(10);
        addhouse->setFont(font1);
        label_2 = new QLabel(usermentPanel);
        label_2->setObjectName(QString::fromUtf8("label_2"));
        label_2->setGeometry(QRect(110, 65, 261, 31));
        label_2->setFont(font);
        label_2->setLayoutDirection(Qt::RightToLeft);
        pushButton_5 = new QPushButton(usermentPanel);
        pushButton_5->setObjectName(QString::fromUtf8("pushButton_5"));
        pushButton_5->setGeometry(QRect(40, 110, 161, 61));
        pushButton_5->setFont(font1);
        pushButton_6 = new QPushButton(usermentPanel);
        pushButton_6->setObjectName(QString::fromUtf8("pushButton_6"));
        pushButton_6->setGeometry(QRect(130, 180, 161, 61));
        pushButton_6->setFont(font1);

        retranslateUi(usermentPanel);

        QMetaObject::connectSlotsByName(usermentPanel);
    } // setupUi

    void retranslateUi(QDialog *usermentPanel)
    {
        usermentPanel->setWindowTitle(QApplication::translate("usermentPanel", "Dialog", nullptr));
        hi->setText(QString());
        addhouse->setText(QApplication::translate("usermentPanel", "\331\205\330\264\330\247\331\207\330\257\331\207 \331\204\333\214\330\263\330\252 \331\207\330\247\333\214 \330\247\330\254\330\247\330\261\331\207 \331\210 \331\201\330\261\331\210\330\264", nullptr));
        label_2->setText(QApplication::translate("usermentPanel", "\331\204\330\267\331\201\330\247 \330\271\331\205\331\204\333\214\330\247\330\252 \331\205\331\210\330\261\330\257 \331\206\330\270\330\261 \330\256\331\210\330\257 \330\261\330\247 \331\210\330\247\330\261\330\257 \332\251\331\206\333\214\330\257.", nullptr));
        pushButton_5->setText(QApplication::translate("usermentPanel", "\331\205\330\264\330\247\331\207\330\257\331\207 \331\205\330\263\332\251\331\206 \331\207\330\247", nullptr));
        pushButton_6->setText(QApplication::translate("usermentPanel", "\331\205\330\264\330\247\331\207\330\257\331\207 \331\205\330\263\332\251\331\206 \331\207\330\247 \330\250\331\207 \330\265\331\210\330\261\330\252 \331\205\330\254\330\262\330\247", nullptr));
    } // retranslateUi

};

namespace Ui {
    class usermentPanel: public Ui_usermentPanel {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_USERMENTPANEL_H
