#ifndef HOUSETYPE_H
#define HOUSETYPE_H

#include <QDialog>

namespace Ui {
class houseType;
}

class houseType : public QDialog
{
    Q_OBJECT

public:
    explicit houseType(QWidget *parent = nullptr);
    ~houseType();

private slots:
    void on_ok_clicked();

private:
    Ui::houseType *ui;
};

#endif // HOUSETYPE_H
