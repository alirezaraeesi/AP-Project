/********************************************************************************
** Form generated from reading UI file 'observe.ui'
**
** Created by: Qt User Interface Compiler version 5.12.3
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_OBSERVE_H
#define UI_OBSERVE_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDialog>
#include <QtWidgets/QLabel>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QRadioButton>

QT_BEGIN_NAMESPACE

class Ui_observe
{
public:
    QRadioButton *apatement;
    QRadioButton *all;
    QLabel *label;
    QPushButton *ok;

    void setupUi(QDialog *observe)
    {
        if (observe->objectName().isEmpty())
            observe->setObjectName(QString::fromUtf8("observe"));
        observe->resize(348, 246);
        apatement = new QRadioButton(observe);
        apatement->setObjectName(QString::fromUtf8("apatement"));
        apatement->setGeometry(QRect(121, 100, 91, 21));
        QFont font;
        font.setFamily(QString::fromUtf8("Nasim"));
        font.setPointSize(12);
        apatement->setFont(font);
        apatement->setLayoutDirection(Qt::RightToLeft);
        all = new QRadioButton(observe);
        all->setObjectName(QString::fromUtf8("all"));
        all->setGeometry(QRect(121, 70, 91, 21));
        all->setFont(font);
        all->setLayoutDirection(Qt::RightToLeft);
        label = new QLabel(observe);
        label->setObjectName(QString::fromUtf8("label"));
        label->setGeometry(QRect(6, 25, 231, 31));
        label->setFont(font);
        label->setLayoutDirection(Qt::RightToLeft);
        ok = new QPushButton(observe);
        ok->setObjectName(QString::fromUtf8("ok"));
        ok->setGeometry(QRect(130, 140, 81, 23));

        retranslateUi(observe);

        QMetaObject::connectSlotsByName(observe);
    } // setupUi

    void retranslateUi(QDialog *observe)
    {
        observe->setWindowTitle(QApplication::translate("observe", "Dialog", nullptr));
        apatement->setText(QApplication::translate("observe", "\330\242\331\276\330\247\330\261\330\252\331\205\330\247\331\206", nullptr));
        all->setText(QApplication::translate("observe", "\331\207\331\205\331\207", nullptr));
        label->setText(QApplication::translate("observe", "\331\204\330\267\331\201\330\247 \331\206\331\210\330\271 \331\205\330\263\332\251\331\206 \330\261\330\247 \330\247\331\206\330\252\330\256\330\247\330\250 \332\251\331\206\333\214\330\257.", nullptr));
        ok->setText(QApplication::translate("observe", "\330\252\330\243\333\214\333\214\330\257", nullptr));
    } // retranslateUi

};

namespace Ui {
    class observe: public Ui_observe {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_OBSERVE_H
