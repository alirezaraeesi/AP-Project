/********************************************************************************
** Form generated from reading UI file 'addapartement.ui'
**
** Created by: Qt User Interface Compiler version 5.12.3
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_ADDAPARTEMENT_H
#define UI_ADDAPARTEMENT_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDialog>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QRadioButton>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_addApartement
{
public:
    QPushButton *confirm;
    QLabel *error;
    QWidget *widget;
    QVBoxLayout *verticalLayout_2;
    QHBoxLayout *horizontalLayout;
    QRadioButton *no;
    QRadioButton *yes;
    QLineEdit *totalarea;
    QLineEdit *numfloor;
    QLineEdit *photo;
    QLineEdit *basecost;
    QLineEdit *address;
    QLineEdit *numhome;
    QWidget *widget1;
    QVBoxLayout *verticalLayout;
    QLabel *label_3;
    QLabel *label_4;
    QLabel *label_5;
    QLabel *label_6;
    QLabel *label_7;
    QLabel *label_8;
    QLabel *label;

    void setupUi(QDialog *addApartement)
    {
        if (addApartement->objectName().isEmpty())
            addApartement->setObjectName(QString::fromUtf8("addApartement"));
        addApartement->resize(468, 435);
        addApartement->setLayoutDirection(Qt::RightToLeft);
        confirm = new QPushButton(addApartement);
        confirm->setObjectName(QString::fromUtf8("confirm"));
        confirm->setGeometry(QRect(190, 280, 91, 31));
        error = new QLabel(addApartement);
        error->setObjectName(QString::fromUtf8("error"));
        error->setGeometry(QRect(160, 330, 201, 31));
        widget = new QWidget(addApartement);
        widget->setObjectName(QString::fromUtf8("widget"));
        widget->setGeometry(QRect(118, 48, 135, 201));
        verticalLayout_2 = new QVBoxLayout(widget);
        verticalLayout_2->setObjectName(QString::fromUtf8("verticalLayout_2"));
        verticalLayout_2->setContentsMargins(0, 0, 0, 0);
        horizontalLayout = new QHBoxLayout();
        horizontalLayout->setObjectName(QString::fromUtf8("horizontalLayout"));
        no = new QRadioButton(widget);
        no->setObjectName(QString::fromUtf8("no"));

        horizontalLayout->addWidget(no);

        yes = new QRadioButton(widget);
        yes->setObjectName(QString::fromUtf8("yes"));

        horizontalLayout->addWidget(yes);


        verticalLayout_2->addLayout(horizontalLayout);

        totalarea = new QLineEdit(widget);
        totalarea->setObjectName(QString::fromUtf8("totalarea"));

        verticalLayout_2->addWidget(totalarea);

        numfloor = new QLineEdit(widget);
        numfloor->setObjectName(QString::fromUtf8("numfloor"));

        verticalLayout_2->addWidget(numfloor);

        photo = new QLineEdit(widget);
        photo->setObjectName(QString::fromUtf8("photo"));

        verticalLayout_2->addWidget(photo);

        basecost = new QLineEdit(widget);
        basecost->setObjectName(QString::fromUtf8("basecost"));

        verticalLayout_2->addWidget(basecost);

        address = new QLineEdit(widget);
        address->setObjectName(QString::fromUtf8("address"));

        verticalLayout_2->addWidget(address);

        numhome = new QLineEdit(widget);
        numhome->setObjectName(QString::fromUtf8("numhome"));

        verticalLayout_2->addWidget(numhome);

        widget1 = new QWidget(addApartement);
        widget1->setObjectName(QString::fromUtf8("widget1"));
        widget1->setGeometry(QRect(260, 50, 69, 201));
        verticalLayout = new QVBoxLayout(widget1);
        verticalLayout->setObjectName(QString::fromUtf8("verticalLayout"));
        verticalLayout->setContentsMargins(0, 0, 0, 0);
        label_3 = new QLabel(widget1);
        label_3->setObjectName(QString::fromUtf8("label_3"));
        QFont font;
        font.setFamily(QString::fromUtf8("Nasim"));
        font.setPointSize(12);
        label_3->setFont(font);
        label_3->setLayoutDirection(Qt::RightToLeft);

        verticalLayout->addWidget(label_3);

        label_4 = new QLabel(widget1);
        label_4->setObjectName(QString::fromUtf8("label_4"));
        label_4->setFont(font);
        label_4->setLayoutDirection(Qt::RightToLeft);

        verticalLayout->addWidget(label_4);

        label_5 = new QLabel(widget1);
        label_5->setObjectName(QString::fromUtf8("label_5"));
        label_5->setFont(font);
        label_5->setLayoutDirection(Qt::RightToLeft);

        verticalLayout->addWidget(label_5);

        label_6 = new QLabel(widget1);
        label_6->setObjectName(QString::fromUtf8("label_6"));
        label_6->setFont(font);
        label_6->setLayoutDirection(Qt::RightToLeft);

        verticalLayout->addWidget(label_6);

        label_7 = new QLabel(widget1);
        label_7->setObjectName(QString::fromUtf8("label_7"));
        label_7->setFont(font);
        label_7->setLayoutDirection(Qt::RightToLeft);

        verticalLayout->addWidget(label_7);

        label_8 = new QLabel(widget1);
        label_8->setObjectName(QString::fromUtf8("label_8"));
        label_8->setFont(font);
        label_8->setLayoutDirection(Qt::RightToLeft);

        verticalLayout->addWidget(label_8);

        label = new QLabel(widget1);
        label->setObjectName(QString::fromUtf8("label"));

        verticalLayout->addWidget(label);


        retranslateUi(addApartement);

        QMetaObject::connectSlotsByName(addApartement);
    } // setupUi

    void retranslateUi(QDialog *addApartement)
    {
        addApartement->setWindowTitle(QApplication::translate("addApartement", "Dialog", nullptr));
        confirm->setText(QApplication::translate("addApartement", "\330\252\330\243\333\214\333\214\330\257", nullptr));
        error->setText(QString());
        no->setText(QApplication::translate("addApartement", "\331\206\330\257\330\247\330\261\330\257", nullptr));
        yes->setText(QApplication::translate("addApartement", "\330\257\330\247\330\261\330\257", nullptr));
        label_3->setText(QApplication::translate("addApartement", "\330\242\330\263\330\247\331\206\330\263\331\210\330\261:", nullptr));
        label_4->setText(QApplication::translate("addApartement", "\331\205\330\263\330\247\330\255\330\252 \332\251\331\204:", nullptr));
        label_5->setText(QApplication::translate("addApartement", "\330\252\330\271\330\257\330\247\330\257 \330\267\330\250\331\202\331\207:", nullptr));
        label_6->setText(QApplication::translate("addApartement", "\330\271\332\251\330\263 \330\242\331\276\330\247\330\261\330\252\331\205\330\247\331\206:", nullptr));
        label_7->setText(QApplication::translate("addApartement", "\331\202\333\214\331\205\330\252 \331\276\330\247\333\214\331\207:", nullptr));
        label_8->setText(QApplication::translate("addApartement", "\330\242\330\257\330\261\330\263:", nullptr));
        label->setText(QApplication::translate("addApartement", "\330\252\330\271\330\257\330\247\330\257 \330\256\330\247\331\206\331\207:", nullptr));
    } // retranslateUi

};

namespace Ui {
    class addApartement: public Ui_addApartement {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_ADDAPARTEMENT_H
