#include "addapartement.h"
#include "ui_addapartement.h"
#include<iostream>
#include<fstream>
#include "apartement.cpp"
#include "home.cpp"
#include "homeinfo.h"
using namespace  std;
addApartement::addApartement(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::addApartement)
{
    ui->setupUi(this);
}

addApartement::~addApartement()
{
    delete ui;
}
int addApartement:: get()
{
    return ui->numhome->text().toInt();
}
void addApartement::on_confirm_clicked()
{
    apartement apart;
    home ho;
    homeinfo *info;
    apart.setTotalArea(ui->totalarea->text().toInt());
    apart.setbasscost(ui->basecost->text().toInt());
    if(ui->yes->isChecked())
    apart.setlift(1);
    else if(ui->no->isChecked())
    apart.setlift(0);
    apart.setnumberfloor(ui->numfloor->text().toInt());
    apart.setPhoto(ui->photo->text().toStdString());
    apart.setaddress(ui->address->text().toStdString());
    //connect(this,SIGNAL(get()),info,SLOT(set()));
    ofstream myfile("apartement/apart",ios::app);
    if (myfile.is_open() == false)
        ui->error->setText("<span style=\"color:red;\">ویلای مورد نظر ثبت نشد</span>");
    else
    {
        myfile <<ui->totalarea->text().toInt()<<" "<<apart.getlift()<< " " << ui->numfloor->text().toInt() << " " << ui->totalarea->text().toInt() <<" "<<ui->photo->text().toStdString()<<" "<<ui->address->text().toStdString()<<endl;
        myfile.close();
        homeinfo i;
        i.exec();
        ui->error->setText("<span style=\"color:green;\">ویلای مورد نظر ثبت شد</span>");
    }

}
