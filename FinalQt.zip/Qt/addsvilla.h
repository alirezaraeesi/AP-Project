#ifndef ADDSVILLA_H
#define ADDSVILLA_H

#include <QDialog>

namespace Ui {
class addSVilla;
}

class addSVilla : public QDialog
{
    Q_OBJECT

public:
    explicit addSVilla(QWidget *parent = nullptr);
    ~addSVilla();

private slots:
    void on_confirm_clicked();

private:
    Ui::addSVilla *ui;
};

#endif // ADDSVILLA_H
