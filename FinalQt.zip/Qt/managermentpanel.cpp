#include "managermentpanel.h"
#include "ui_managermentpanel.h"
#include "housetype.h"
#include "see.h"
managermentPanel::managermentPanel(QString a,QWidget *parent) :
    QDialog(parent),
    ui(new Ui::managermentPanel)
{
    ui->setupUi(this);
    name=a;
    ui->hi->setText("Dear "+name);
}
managermentPanel::~managermentPanel()
{
    delete ui;
}
void managermentPanel::setname(QString name)
{
    this->name=name;
}
QString managermentPanel::getname()
{
    return name;
}

void managermentPanel::on_addhouse_clicked()
{
    houseType h;
    h.exec();
}

void managermentPanel::on_pushButton_5_clicked()
{
    see s;
    s.exec();
}
