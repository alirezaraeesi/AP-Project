/********************************************************************************
** Form generated from reading UI file 'seesvilla.ui'
**
** Created by: Qt User Interface Compiler version 5.12.3
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_SEESVILLA_H
#define UI_SEESVILLA_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDialog>
#include <QtWidgets/QLabel>
#include <QtWidgets/QTextEdit>

QT_BEGIN_NAMESPACE

class Ui_seesvilla
{
public:
    QTextEdit *textEdit;
    QLabel *error;

    void setupUi(QDialog *seesvilla)
    {
        if (seesvilla->objectName().isEmpty())
            seesvilla->setObjectName(QString::fromUtf8("seesvilla"));
        seesvilla->resize(491, 495);
        textEdit = new QTextEdit(seesvilla);
        textEdit->setObjectName(QString::fromUtf8("textEdit"));
        textEdit->setGeometry(QRect(100, 10, 281, 471));
        error = new QLabel(seesvilla);
        error->setObjectName(QString::fromUtf8("error"));
        error->setGeometry(QRect(30, 260, 47, 13));

        retranslateUi(seesvilla);

        QMetaObject::connectSlotsByName(seesvilla);
    } // setupUi

    void retranslateUi(QDialog *seesvilla)
    {
        seesvilla->setWindowTitle(QApplication::translate("seesvilla", "Dialog", nullptr));
        error->setText(QApplication::translate("seesvilla", "TextLabel", nullptr));
    } // retranslateUi

};

namespace Ui {
    class seesvilla: public Ui_seesvilla {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_SEESVILLA_H
