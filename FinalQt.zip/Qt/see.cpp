#include "see.h"
#include "ui_see.h"
#include "seeapartement.h"
#include "seenvilla.h"
#include "seesvilla.h"
see::see(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::see)
{
    ui->setupUi(this);
}

see::~see()
{
    delete ui;
}

void see::on_ok_clicked()
{
    seenvilla nv;
    seesvilla sv;
    seeapartement a;
    if(ui->nvilla->isChecked())
    {
        nv.exec();
    }
    else if(ui->svilla->isChecked())
    {
        sv.exec();
    }
    else if(ui->apatement->isChecked())
    {
        a.exec();
    }
}
