#include "user.h"
#include<iostream>
#include<string>
#include<algorithm>
#include<vector>
#include<string.h>
#include<list>


user::user()
{
        fname="NULL";
        lname="NULL";
        birthday ="NULL";
        username ="NULL";
        password ="NULL";
	stock = 0;
	usercondition = 1;
}

user::user(string name,string lname, string birthday, string username, string password)
{
	this->fname = name;
	this->lname=lname;
	this->birthday = birthday;
	this->username = username;
	this->password = password;
	stock = 0;
	usercondition = 1;
}

//list<rentfile>rent;
//list<sellfile>sell;

void user::setfname(string name)
{
	this->fname = name;
}

string user::getfname()
{
	return fname;
}

void user::setlname(string name)
{
	this->lname = name;
}

string user::getlname()
{
	return lname;
}

void user::setusername(string username)
{
	this->username = username;
}

string user::getusername()
{
	return username;
}

void user::setpassword(string password)
{
	this->password = password;
}

string user::getpassword()
{
	return password;
}

void user::setbirthday(string birthday)
{
	this->birthday = birthday;
}

string user::getbirthday()
{
	return birthday;
}

void user::settimelogout(string timelogout)
{
	this->timelogout = timelogout;
}

string user::gettimelogout()
{
	return timelogout;
}

void user::settimeinput(string timeinput)
{
	this->timelogout = timeinput;
}

string user::gettimeinput()
{
	return timeinput;
}

user::~user()
{
}
