#ifndef MAINWINDOW_H
#define MAINWINDOW_H
#include<iostream>
#include<vector>
#include <QMainWindow>
using namespace  std;
#include "north.h"
namespace Ui {
class MainWindow;
}

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = nullptr);
    void set(north);
    vector<north> get();
    ~MainWindow();

private slots:
    void on_signin_clicked();

    void on_signup_clicked();

private:
    Ui::MainWindow *ui;
    vector<north>no;
};

#endif // MAINWINDOW_H
