#include "homeinfo.h"
#include "ui_homeinfo.h"
#include "home.h"
homeinfo::homeinfo(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::homeinfo)
{

    ui->setupUi(this);
}

homeinfo::~homeinfo()
{
    delete ui;
}

void homeinfo::on_confirm_clicked()
{
    home ho;
    ho.setFloorNum(ui->floornum->text().toInt());
    ho.setPhoto(ui->photo->text().toStdString());
    ho.setRoomsNum(ui->rommsnum->text().toInt());
    ho.setBuiltArea(ui->builtarea->text().toInt());

}
void homeinfo::set(int a)
{
     homeinfo t;
 for(int i=1;i<=a;i++)
 {
    t.exec();
    ui->number->setText(QString::number(i));
 }
}
