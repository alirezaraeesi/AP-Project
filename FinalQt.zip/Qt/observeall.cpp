#include "observeall.h"
#include "ui_observeall.h"
#include "north.h"
#include "south.h"
#include "apartement.h"
#include "home.h"
#include <iostream>
#include <fstream>
#include <vector>
using namespace std;
observeall::observeall(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::observeall)
{
    ui->setupUi(this);
}

observeall::~observeall()
{
    delete ui;
}

void observeall::on_pushButton_clicked()
{
    north n;
    south s;
    apartement a;
    vector<north> no;
    vector<south> so;
    vector<apartement>ap;
    ifstream infile("villa/nvilla");
    ifstream infile1("villa/svilla");
    int ba,fa,backa,ca,rn,bc;
    string ph,type;
    string ad;
    north temp;

    if(infile.is_open() == 1)
    {
        while(1)
        {
            if(!infile.eof())
            {
                infile>>ba>>fa>>backa>>ca>>rn>>ph>>bc>>ad;
                n.setareabuilt(ba);
                n.setFrontYardArea(fa);
                n.setBackYard(backa);
                n.setTotalArea(ca);
                n.setnumrooms(rn);
                n.setPhoto(ph);
                n.setbasscost(bc);
                n.setaddress(ad);
                no.push_back(n);

            }
            else
            {
                break;
            }

        }
    }
    if(infile1.is_open() == 1)
    {
        while(1)
        {
            if(!infile1.eof())
            {
                infile1>>type>>ba>>fa>>backa>>ca>>rn>>ph>>bc>>ad;
                s.setareabuilt(ba);
                s.setareayard(fa);
                s.setParkingArea(backa);
                s.setTotalArea(ca);
                s.setnumrooms(rn);
                s.setPhoto(ph);
                s.setbasscost(bc);
                s.setaddress(ad);
                so.push_back(s);

            }
            else
            {
                break;
            }

        }
    }
    else
    {
        //ui->error->setText("<span style=\"color:red;\">هیچ ویلایی برای نمایش وجود ندارد</span>");
    }
    if(ui->sort->isChecked())
    {
        for (int i = 0; i < no.size()-1; i++)
            {
                for (int j = 0; j < no.size()-i-1; j++)
                {
                    if(no[j].computetotalcost()>no[j+1].computetotalcost())
                    {
                        temp.setaddress(no[j].getaddress());
                        temp.setareabuilt(no[j].getareabuilt());
                        //temp.setareayard(no[j].getareayard());
                        temp.setbasscost(no[j].getbasscost());
                        temp.setnumrooms(no[j].getnumfllors());
                        //temp.settotalcost1(no[j].computetotalcost());
                        no[j].setaddress(no[j+1].getaddress());
                        no[j].setareabuilt(no[j+1].getareabuilt());
                        //no[j].setareayard(vil[j+1].getareayard());
                        no[j].setbasscost(no[j+1].getbasscost());
                        no[j].setnumrooms(no[j+1].getnumfllors());
                        //vil[j].settotalcost1(vil[j+1].computetotalcost());
                        no[j+1].setaddress(temp.getaddress());
                        no[j+1].setareabuilt(temp.getareabuilt());
                        //vil[j+1].setareayard(temp.getareayard());
                        no[j+1].setbasscost(temp.getbasscost());
                        no[j+1].setnumrooms(temp.getnumfllors());
                        //vil[j+1].settotalcost1(temp.computetotalcost());
                    }
                }
            }
        if(ui->price->text().toStdString()!="NULL"&& ui->builtarea->text().toStdString()!="NULL")
        {

        for( int i=0;i<no.size();i++)
        {
            if(no[i].getbasscost()<ui->price->text().toInt() && no[i].getareabuilt()>ui->builtarea->text().toInt())
             ui->textEdit->insertPlainText(QString::fromStdString(type)+" "+QString::number(no[i].getareabuilt())+" "+QString::number(no[i].getFrontYardArea())+" "+QString::number(no[i].getBackYard())+" "+QString::number(no[i].getTotalArea())+" "+QString::number(no[i].getnumfllors())+" "+QString::fromStdString(no[i].getPhoto())+" "+QString::number(no[i].getbasscost())+" "+QString::fromStdString(no[i].getaddress())+"\n");
        }
        for( int i=0;i<so.size();i++)
        {
            if(so[i].getbasscost()<ui->price->text().toInt() && so[i].getareabuilt()>ui->builtarea->text().toInt())
            ui->textEdit->insertPlainText(QString::fromStdString(type)+" "+QString::number(so[i].getareabuilt())+" "+QString::number(so[i].getareayard())+" "+QString::number(so[i].getParkingArea())+" "+QString::number(so[i].getTotalArea())+" "+QString::number(so[i].getnumfllors())+" "+QString::fromStdString(so[i].getPhoto())+" "+QString::number(so[i].getbasscost())+" "+QString::fromStdString(so[i].getaddress())+"\n");
        }
        }
        if(ui->street->text().toStdString()!="Null")
        {
            for(int i=0;i<no.size();i++)
                {
                    if(no[i].getaddress().find(ui->street->text().toStdString())!=-1)
                       ui->textEdit->insertPlainText(QString::fromStdString(type)+" "+QString::number(no[i].getareabuilt())+" "+QString::number(no[i].getFrontYardArea())+" "+QString::number(no[i].getBackYard())+" "+QString::number(no[i].getTotalArea())+" "+QString::number(no[i].getnumfllors())+" "+QString::fromStdString(no[i].getPhoto())+" "+QString::number(no[i].getbasscost())+" "+QString::fromStdString(no[i].getaddress())+"\n");
                }
            for(int i=0;i<so.size();i++)
                {
                    if(so[i].getaddress().find(ui->street->text().toStdString())!=-1)
                       ui->textEdit->insertPlainText(QString::fromStdString(type)+" "+QString::number(so[i].getareabuilt())+" "+QString::number(so[i].getareayard())+" "+QString::number(so[i].getParkingArea())+" "+QString::number(so[i].getTotalArea())+" "+QString::number(so[i].getnumfllors())+" "+QString::fromStdString(so[i].getPhoto())+" "+QString::number(so[i].getbasscost())+" "+QString::fromStdString(so[i].getaddress())+"\n");
                }
        }
    }


}
