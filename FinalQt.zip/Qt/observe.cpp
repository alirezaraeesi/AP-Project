#include "observe.h"
#include "ui_observe.h"
#include "observeall.h"
#include "observeapartement.h"
observe::observe(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::observe)
{
    ui->setupUi(this);
}

observe::~observe()
{
    delete ui;
}

void observe::on_ok_clicked()
{
    observeall all;
    observeapartement ap;
    if(ui->all->isChecked())
    {
        all.exec();
    }
    else if(ui->apatement->isChecked())
    {
        ap.exec();
    }
}
