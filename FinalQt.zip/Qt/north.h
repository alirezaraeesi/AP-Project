#pragma once
#include "villa.h"
class north :
	public villa
{
	int backYardArea;
	int frontYardArea;
public:
	north();
	north(int, int, int, int, int, string, int, string);
	void setBackYard(int);
	int getBackYard();
	void setFrontYardArea(int);
	int getFrontYardArea();
	long long int computetotalcost();
	~north();
};

