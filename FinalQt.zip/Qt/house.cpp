#include "house.h"



house::house()
{
	this->totalArea = 0;
	this->baseCost = 0;
	this->address = "NULL";
}

house::house(int areabuilt, int basscost, string address)
{
	this->totalArea = areabuilt;
	this->baseCost = basscost;
	this->address = address;
}

void house::setTotalArea(int _area)
{
	totalArea = _area;
}

int house::getTotalArea()
{
	return totalArea;
}

void house::setaddress(string address)
{
	this->address = address;
}

string house::getaddress()
{
	return address;
}

void house::setbasscost(int basscost)
{
	this->baseCost = basscost;
}

int house::getbasscost()
{
	return baseCost;
}


house::~house()
{
}
