#ifndef HOMEINFO_H
#define HOMEINFO_H

#include <QDialog>

namespace Ui {
class homeinfo;
}

class homeinfo : public QDialog
{
    Q_OBJECT

public:
    explicit homeinfo(QWidget *parent = nullptr);
    void set(int);
    ~homeinfo();

private slots:
    void on_confirm_clicked();

private:
    Ui::homeinfo *ui;
};

#endif // HOMEINFO_H
