#include "file.h"



file::file()
{
	int commission = 0;
}

file::file(int commission)
{
	this->commission = commission;
}

void file::setcommission(int _commission)
{
	commission = _commission;
}

int file::getcommission()
{
	return commission;
}


long long int file::totalcost()
{
	return 0;
}

file::~file()
{
}
