#pragma once
#include "user.h"
class boardmanager :
	public user
{
public:
	boardmanager();
	~boardmanager();
};

