#ifndef MANAGERSIGNIN_H
#define MANAGERSIGNIN_H

#include <QDialog>

namespace Ui {
class managerSignin;
}

class managerSignin : public QDialog
{
    Q_OBJECT

public:
    explicit managerSignin(QWidget *parent = nullptr);
    ~managerSignin();

private slots:
    void on_signin_clicked();

private:
    Ui::managerSignin *ui;
};

#endif // MANAGERSIGNIN_H
