#include "observeapartement.h"
#include "ui_observeapartement.h"

observeapartement::observeapartement(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::observeapartement)
{
    ui->setupUi(this);
}

observeapartement::~observeapartement()
{
    delete ui;
}
