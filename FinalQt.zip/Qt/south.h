#pragma once
#include "villa.h"
class south :
	public villa
{
	int yardArea;
	int parkingArea;
public:
	south();
	south(int, int, int, int, int, string, int, string);
	void setareayard(int );
	int getareayard();
	void setParkingArea(int );
	int getParkingArea();
	long long int computetotalcost();
	~south();
};

