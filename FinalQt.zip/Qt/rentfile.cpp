#include "rentfile.h"
#include "house.h"
#include "villa.h"
#include "apartement.h"
#include "north.h"
#include "south.h"


rentfile::rentfile()
{
	this->renttime = 0;
}

rentfile::rentfile(villa * obj, int commission, int renttime):file(commission)
{
	villa *r = dynamic_cast<north*>(obj);
	if (r)
	{
		this->mr1 = obj->computetotalcost()*0.05;
		this->mrent1 = obj->computetotalcost()*0.01;
	}
	else
	{
		this->mr1 = obj->computetotalcost()*0.05;
		this->mrent1 = obj->computetotalcost()*0.01;
	}
	/*apartement *a = dynamic_cast<apartement*>(obj);
	if (a)
	{
		this->mr1 = obj->computetotalcost()*0.05;
		this->mrent1 = obj->computetotalcost()*0.01;
	}*/

	this->renttime = renttime;
}

long long int rentfile::totalcost()
{
	return (this->mrent1*this->renttime) + this->mr1 + (this->commission*this->mr1);
}

int rentfile::getrenttime()
{
	return renttime;
}

int rentfile::getmr1()
{
	return mr1;
}

int rentfile::getmrent1()
{
	return mrent1;
}


rentfile::~rentfile()
{
}
