/********************************************************************************
** Form generated from reading UI file 'managermentpanel.ui'
**
** Created by: Qt User Interface Compiler version 5.12.3
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MANAGERMENTPANEL_H
#define UI_MANAGERMENTPANEL_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDialog>
#include <QtWidgets/QLabel>
#include <QtWidgets/QPushButton>

QT_BEGIN_NAMESPACE

class Ui_managermentPanel
{
public:
    QLabel *hi;
    QLabel *label_2;
    QPushButton *addhouse;
    QPushButton *pushButton_2;
    QPushButton *pushButton_5;
    QPushButton *pushButton_6;

    void setupUi(QDialog *managermentPanel)
    {
        if (managermentPanel->objectName().isEmpty())
            managermentPanel->setObjectName(QString::fromUtf8("managermentPanel"));
        managermentPanel->resize(400, 300);
        hi = new QLabel(managermentPanel);
        hi->setObjectName(QString::fromUtf8("hi"));
        hi->setGeometry(QRect(140, 20, 231, 31));
        QFont font;
        font.setFamily(QString::fromUtf8("Nasim"));
        font.setPointSize(12);
        hi->setFont(font);
        hi->setLayoutDirection(Qt::RightToLeft);
        label_2 = new QLabel(managermentPanel);
        label_2->setObjectName(QString::fromUtf8("label_2"));
        label_2->setGeometry(QRect(110, 45, 261, 31));
        label_2->setFont(font);
        label_2->setLayoutDirection(Qt::RightToLeft);
        addhouse = new QPushButton(managermentPanel);
        addhouse->setObjectName(QString::fromUtf8("addhouse"));
        addhouse->setGeometry(QRect(240, 90, 131, 61));
        QFont font1;
        font1.setFamily(QString::fromUtf8("B Sara"));
        font1.setPointSize(10);
        addhouse->setFont(font1);
        pushButton_2 = new QPushButton(managermentPanel);
        pushButton_2->setObjectName(QString::fromUtf8("pushButton_2"));
        pushButton_2->setGeometry(QRect(50, 90, 131, 61));
        pushButton_2->setFont(font1);
        pushButton_5 = new QPushButton(managermentPanel);
        pushButton_5->setObjectName(QString::fromUtf8("pushButton_5"));
        pushButton_5->setGeometry(QRect(50, 160, 131, 61));
        pushButton_5->setFont(font1);
        pushButton_6 = new QPushButton(managermentPanel);
        pushButton_6->setObjectName(QString::fromUtf8("pushButton_6"));
        pushButton_6->setGeometry(QRect(240, 160, 131, 61));
        pushButton_6->setFont(font1);

        retranslateUi(managermentPanel);

        QMetaObject::connectSlotsByName(managermentPanel);
    } // setupUi

    void retranslateUi(QDialog *managermentPanel)
    {
        managermentPanel->setWindowTitle(QApplication::translate("managermentPanel", "Dialog", nullptr));
        hi->setText(QString());
        label_2->setText(QApplication::translate("managermentPanel", "\331\204\330\267\331\201\330\247 \330\271\331\205\331\204\333\214\330\247\330\252 \331\205\331\210\330\261\330\257 \331\206\330\270\330\261 \330\256\331\210\330\257 \330\261\330\247 \331\210\330\247\330\261\330\257 \332\251\331\206\333\214\330\257.", nullptr));
        addhouse->setText(QApplication::translate("managermentPanel", "\330\247\330\266\330\247\331\201\331\207 \332\251\330\261\330\257\331\206 \331\205\330\263\332\251\331\206", nullptr));
        pushButton_2->setText(QApplication::translate("managermentPanel", "\331\210\333\214\330\261\330\247\333\214\330\264 \331\205\330\263\332\251\331\206", nullptr));
        pushButton_5->setText(QApplication::translate("managermentPanel", "\331\205\330\264\330\247\331\207\330\257\331\207 \330\247\330\267\331\204\330\247\330\271\330\247\330\252", nullptr));
        pushButton_6->setText(QApplication::translate("managermentPanel", "\331\205\330\257\333\214\330\261\333\214\330\252 \331\276\330\261\331\210\331\206\330\257\331\207 \331\207\330\247", nullptr));
    } // retranslateUi

};

namespace Ui {
    class managermentPanel: public Ui_managermentPanel {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MANAGERMENTPANEL_H
