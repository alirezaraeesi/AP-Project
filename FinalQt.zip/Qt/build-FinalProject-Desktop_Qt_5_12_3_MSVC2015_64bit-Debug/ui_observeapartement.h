/********************************************************************************
** Form generated from reading UI file 'observeapartement.ui'
**
** Created by: Qt User Interface Compiler version 5.12.3
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_OBSERVEAPARTEMENT_H
#define UI_OBSERVEAPARTEMENT_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDialog>

QT_BEGIN_NAMESPACE

class Ui_observeapartement
{
public:

    void setupUi(QDialog *observeapartement)
    {
        if (observeapartement->objectName().isEmpty())
            observeapartement->setObjectName(QString::fromUtf8("observeapartement"));
        observeapartement->resize(400, 300);

        retranslateUi(observeapartement);

        QMetaObject::connectSlotsByName(observeapartement);
    } // setupUi

    void retranslateUi(QDialog *observeapartement)
    {
        observeapartement->setWindowTitle(QApplication::translate("observeapartement", "Dialog", nullptr));
    } // retranslateUi

};

namespace Ui {
    class observeapartement: public Ui_observeapartement {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_OBSERVEAPARTEMENT_H
