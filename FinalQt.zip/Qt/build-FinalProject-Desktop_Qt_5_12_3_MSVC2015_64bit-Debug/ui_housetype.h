/********************************************************************************
** Form generated from reading UI file 'housetype.ui'
**
** Created by: Qt User Interface Compiler version 5.12.3
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_HOUSETYPE_H
#define UI_HOUSETYPE_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDialog>
#include <QtWidgets/QLabel>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QRadioButton>

QT_BEGIN_NAMESPACE

class Ui_houseType
{
public:
    QRadioButton *apatement;
    QRadioButton *svilla;
    QRadioButton *nvilla;
    QPushButton *ok;
    QLabel *label;

    void setupUi(QDialog *houseType)
    {
        if (houseType->objectName().isEmpty())
            houseType->setObjectName(QString::fromUtf8("houseType"));
        houseType->resize(338, 217);
        apatement = new QRadioButton(houseType);
        apatement->setObjectName(QString::fromUtf8("apatement"));
        apatement->setGeometry(QRect(121, 120, 91, 21));
        QFont font;
        font.setFamily(QString::fromUtf8("Nasim"));
        font.setPointSize(12);
        apatement->setFont(font);
        apatement->setLayoutDirection(Qt::RightToLeft);
        svilla = new QRadioButton(houseType);
        svilla->setObjectName(QString::fromUtf8("svilla"));
        svilla->setGeometry(QRect(121, 90, 91, 21));
        svilla->setFont(font);
        svilla->setLayoutDirection(Qt::RightToLeft);
        nvilla = new QRadioButton(houseType);
        nvilla->setObjectName(QString::fromUtf8("nvilla"));
        nvilla->setGeometry(QRect(121, 60, 91, 21));
        nvilla->setFont(font);
        nvilla->setLayoutDirection(Qt::RightToLeft);
        ok = new QPushButton(houseType);
        ok->setObjectName(QString::fromUtf8("ok"));
        ok->setGeometry(QRect(130, 160, 81, 23));
        QFont font1;
        font1.setFamily(QString::fromUtf8("B Sara"));
        font1.setPointSize(10);
        ok->setFont(font1);
        label = new QLabel(houseType);
        label->setObjectName(QString::fromUtf8("label"));
        label->setGeometry(QRect(5, 15, 231, 31));
        label->setFont(font);
        label->setLayoutDirection(Qt::RightToLeft);

        retranslateUi(houseType);

        QMetaObject::connectSlotsByName(houseType);
    } // setupUi

    void retranslateUi(QDialog *houseType)
    {
        houseType->setWindowTitle(QApplication::translate("houseType", "Dialog", nullptr));
        apatement->setText(QApplication::translate("houseType", "\330\242\331\276\330\247\330\261\330\252\331\205\330\247\331\206", nullptr));
        svilla->setText(QApplication::translate("houseType", "\331\210\333\214\331\204\330\247\333\214\333\214 \330\254\331\206\331\210\330\250\333\214", nullptr));
        nvilla->setText(QApplication::translate("houseType", "\331\210\333\214\331\204\330\247\333\214\333\214 \330\264\331\205\330\247\331\204\333\214", nullptr));
        ok->setText(QApplication::translate("houseType", "\330\252\330\243\333\214\333\214\330\257", nullptr));
        label->setText(QApplication::translate("houseType", "\331\204\330\267\331\201\330\247 \331\206\331\210\330\271 \331\205\330\263\332\251\331\206 \330\261\330\247 \330\247\331\206\330\252\330\256\330\247\330\250 \332\251\331\206\333\214\330\257.", nullptr));
    } // retranslateUi

};

namespace Ui {
    class houseType: public Ui_houseType {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_HOUSETYPE_H
