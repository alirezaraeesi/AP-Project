#ifndef USERSIGNIN_H
#define USERSIGNIN_H

#include <QDialog>

namespace Ui {
class userSignin;
}

class userSignin : public QDialog
{
    Q_OBJECT

public:
    explicit userSignin(QWidget *parent = nullptr);
    ~userSignin();

private slots:
    void on_signin_clicked();

private:
    Ui::userSignin *ui;
};

#endif // USERSIGNIN_H
