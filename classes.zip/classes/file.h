#pragma once
class file
{
protected:
	int commission;
public:
	file();
	file(int commission);
	void setcommission(int _commission);
	int getcommission();
	virtual long long int totalcost();
	~file();
};

