#include "usersignup.h"
#include "ui_usersignup.h"
#include "user.cpp"
#include <iostream>
#include <fstream>
using namespace std;

userSignup::userSignup(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::userSignup)
{
    ui->setupUi(this);

    //QColor col=QColor(Qt::green);
    //QString qss=QString("background-color:%1").arg(col.name());
    //ui->confirm->setStyleSheet(qss);
}

userSignup::~userSignup()
{
    delete ui;
}

void userSignup::on_confirm_clicked()
{
    user u;
    ifstream infile("users/"+ui->username->text().toStdString());
    if(ui->fname->text()==nullptr || ui->lname->text()==nullptr || ui->username->text()==nullptr || ui->password->text()==nullptr || ui->repassword->text()==nullptr)
    {
        ui->error->setText("<span style=\"color:red;\">لطفا تمامی فیلد ها را پر کرده و تاریخ تولدتان را مشخص کنید</span>");
    }
    else
    {
        if(ui->password->text()==ui->repassword->text() && infile.is_open() == false)
        {
            u.setpassword(ui->password->text().toStdString());
            u.setusername(ui->username->text().toStdString());
            u.setbirthday(ui->birthday->selectedDate().toString().toStdString());
            u.setfname(ui->fname->text().toStdString());
            u.setlname(ui->lname->text().toStdString());
            ofstream myfile("users/"+ui->username->text().toStdString(),ios::app);
            if (myfile.is_open() == false)
                        ui->error->setText("<span style=\"color:red;\">حساب مورد نظر ساخته نشد</span>");
                    else
                    {
                        myfile <<ui->password->text().toStdString()<<endl<< ui->fname->text().toStdString() << " " << ui->lname->text().toStdString() << endl << ui->birthday->selectedDate().toString().toStdString() <<endl<<"0"<<endl<<"1";
                        myfile.close();
                        ui->error->setText("<span style=\"color:green;\">حساب مورد نظر ساخته شد</span>");
                    }
        }
        else
        {
            ui->error->setText("<span style=\"color:red;>تکرار رمز عبور شما با رمز عبورتان یکسان نیست</span>");
        }
    }
}
