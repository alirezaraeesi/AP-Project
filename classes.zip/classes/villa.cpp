#include "villa.h"



villa::villa()
{
	builtArea = 0;
	roomsNum = 0;
	photo = "NULL";
}

villa::villa(int totalArea, int areabuilt, int basecost, int roomsNum, string address, string photo) :house(totalArea, basecost, address)
{
	this->builtArea=areabuilt;
	this->roomsNum = roomsNum;
	this->photo = photo;
}

//void villa::setareayard(int areayard)
//{
//	this->areayard = areayard;
//}
//
//int villa::getareayard()
//{
//	return areayard;
//}

void villa::setnumrooms(int numrooms)
{
	this->roomsNum = numrooms;
}

int villa::getnumfllors()
{
	return roomsNum;
}

void villa::setPhoto(string _photo)
{
	photo = _photo;
}

string villa::getPhoto()
{
	return photo;
}

void villa::setareabuilt(int areabuilt)
{
	this->builtArea = areabuilt;
}

int villa::getareabuilt()
{
	return builtArea;
}

long long int villa::computetotalcost()
{
	return 0;
}

villa::~villa()
{
}
