#include "seenvilla.h"
#include "ui_seenvilla.h"
#include "addnvilla.h"
#include "north.h"
#include<vector>
#include<iostream>
#include<fstream>
#include <QListView>
using namespace std;
seenvilla::seenvilla(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::seenvilla)
{
    ui->setupUi(this);
    ifstream infile("villa/nvilla");
    int ba,fa,backa,ca,rn,bc;
    string ph;
    string ad;

    if(infile.is_open() == 1)
    {
        while(1)
        {
            infile>>ba>>fa>>backa>>ca>>rn>>ph>>bc>>ad;
            QString s = QString::number(ba);
            QString s1=QString::fromStdString(ad);
            if(!infile.eof())
            ui->textEdit->insertPlainText(QString::number(ba)+" "+QString::number(fa)+" "+QString::number(backa)+" "+QString::number(ca)+" "+QString::number(rn)+" "+QString::fromStdString(ph)+" "+QString::number(bc)+" "+QString::fromStdString(ad)+"\n");
            else
            {
                break;
            }

        }
    }
    else
    {
        ui->error->setText("<span style=\"color:red;\">هیچ ویلایی برای نمایش وجود ندارد</span>");
    }
}

seenvilla::~seenvilla()
{
    delete ui;
}
