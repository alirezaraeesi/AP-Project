#pragma once
#include "house.h"
class villa :
	public house
{
protected:
	int builtArea;
	int roomsNum;
	string photo;
public:
	villa();
	villa(int totalArea, int areabuilt, int basecost, int roomsNum, string address, string photo);
	void setareabuilt(int areabuilt);
	int getareabuilt();
	void setnumrooms(int roomsNum);
	int getnumfllors();
	void setPhoto(string _photo);
	string getPhoto();
	virtual long long int computetotalcost();
	~villa();
};

