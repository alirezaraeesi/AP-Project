#ifndef ADDNVILLA_H
#define ADDNVILLA_H

#include <QDialog>

namespace Ui {
class addNVilla;
}

class addNVilla : public QDialog
{
    Q_OBJECT

public:
    explicit addNVilla(QWidget *parent = nullptr);
    ~addNVilla();

private slots:
    void on_confirm_clicked();

private:
    Ui::addNVilla *ui;
};

#endif // ADDNVILLA_H
