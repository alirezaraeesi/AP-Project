#include "seesvilla.h"
#include "ui_seesvilla.h"
#include<iostream>
using namespace std;
#include<fstream>
seesvilla::seesvilla(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::seesvilla)
{
    ui->setupUi(this);
    ifstream infile("villa/svilla");
    int ba,fa,backa,ca,rn,bc;
    string ph;
    string ad;

    if(infile.is_open() == 1)
    {
        while(1)
        {
            infile>>ba>>fa>>backa>>ca>>rn>>ph>>bc>>ad;
            QString s = QString::number(ba);
            QString s1=QString::fromStdString(ad);
            if(!infile.eof())
            ui->textEdit->insertPlainText(QString::number(ba)+" "+QString::number(fa)+" "+QString::number(backa)+" "+QString::number(ca)+" "+QString::number(rn)+" "+QString::fromStdString(ph)+" "+QString::number(bc)+" "+QString::fromStdString(ad)+"\n");
            else
            {
                break;
            }

        }
    }
    else
    {
        ui->error->setText("<span style=\"color:red;\">هیچ ویلایی برای نمایش وجود ندارد</span>");
    }
}


seesvilla::~seesvilla()
{
    delete ui;
}
