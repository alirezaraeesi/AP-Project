#ifndef SEEAPARTEMENT_H
#define SEEAPARTEMENT_H

#include <QDialog>

namespace Ui {
class seeapartement;
}

class seeapartement : public QDialog
{
    Q_OBJECT

public:
    explicit seeapartement(QWidget *parent = nullptr);
    ~seeapartement();

private:
    Ui::seeapartement *ui;
};

#endif // SEEAPARTEMENT_H
