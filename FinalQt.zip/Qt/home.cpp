#include "home.h"



home::home()
{
	floorNum = 0;
	roomsNum = 0;
	builtArea = 0;
	photo = "NULL";
}

home::home(int _floorNum, int _roomsNum, int _builtArea, string _photo)
{
	floorNum = _floorNum;
	roomsNum = _roomsNum;
	builtArea = _builtArea;
	photo = _photo;
}

void home::setFloorNum(int _floorNum)
{
	floorNum = _floorNum;
}

int home::getFloorNum()
{
	return floorNum;
}

void home::setRoomsNum(int _roomsNum)
{
	roomsNum = _roomsNum;
}

int home::getRoomNum()
{
	return roomsNum;
}

void home::setBuiltArea(int _builtArea)
{
	builtArea = _builtArea;
}

int home::getBuiltArea()
{
	return builtArea;
}

void home::setPhoto(string _photo)
{
	photo = _photo;
}

string home::getPhoto()
{
	return photo;
}


home::~home()
{
}
