#ifndef MANAGERSIGNUP_H
#define MANAGERSIGNUP_H

#include <QDialog>

namespace Ui {
class managerSignup;
}

class managerSignup : public QDialog
{
    Q_OBJECT

public:
    explicit managerSignup(QWidget *parent = nullptr);
    ~managerSignup();

private slots:
    void on_confirm_clicked();

   // void on_confirm_2_clicked();

private:
    Ui::managerSignup *ui;
};

#endif // MANAGERSIGNUP_H
