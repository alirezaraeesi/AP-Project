#include "addnvilla.h"
#include "ui_addnvilla.h"
#include "house.cpp"
#include "villa.cpp"
#include "north.cpp"
#include "seenvilla.h"
#include<vector>
#include<iostream>
#include<fstream>
#include "managermentpanel.h"
#include "mainwindow.h"
using namespace std;
addNVilla::addNVilla(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::addNVilla)
{
    ui->setupUi(this);
}

addNVilla::~addNVilla()
{
    delete ui;
}

void addNVilla::on_confirm_clicked()
{
    north n;
    //managermentPanel m;
    n.setareabuilt(ui->builtarea->text().toInt());
    n.setFrontYardArea(ui->frontyard->text().toInt());
    n.setBackYard(ui->backyard->text().toInt());
    n.setTotalArea(ui->totalarea->text().toInt());
    n.setnumrooms(ui->roomsnum->text().toInt());
    n.setPhoto(ui->photo->text().toStdString());
    n.setbasscost(ui->basecost->text().toInt());
    n.setaddress(ui->address->text().toStdString());
   // w.set(n);
    ofstream myfile("villa/nvilla",ios::app);
    if (myfile.is_open() == false)
        ui->error->setText("<span style=\"color:red;\">ویلای مورد نظر ثبت نشد</span>");
    else
    {
        myfile <<ui->builtarea->text().toInt()<<" "<<ui->frontyard->text().toInt()<< " " << ui->backyard->text().toInt() << " " << ui->totalarea->text().toInt() <<" "<<ui->roomsnum->text().toInt()<<" "<<ui->photo->text().toStdString()<<" "<< ui->basecost->text().toInt()<<" "<< ui->address->text().toStdString()<<endl;
        myfile.close();
        ui->error->setText("<span style=\"color:green;\">ویلای مورد نظر ثبت شد</span>");
    }

}
