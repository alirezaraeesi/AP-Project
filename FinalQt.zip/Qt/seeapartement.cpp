#include "seeapartement.h"
#include "ui_seeapartement.h"
#include<iostream>
using namespace std;
#include<fstream>
seeapartement::seeapartement(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::seeapartement)
{
    ui->setupUi(this);
    ifstream infile("apartement/apart");
    int ba,fa,backa,ca;
    string ph;
    string ad;

    if(infile.is_open() == 1)
    {
        while(1)
        {
            infile>>ba>>fa>>backa>>ca>>ph>>ad;
            if(!infile.eof())
            ui->textEdit->insertPlainText(QString::number(ba)+" "+QString::number(fa)+" "+QString::number(backa)+" "+QString::number(ca)+" "+QString::fromStdString(ph)+" "+QString::fromStdString(ad)+"\n");
            else
            {
                break;
            }

        }
    }
    else
    {
        ui->error->setText("<span style=\"color:red;\">هیچ ویلایی برای نمایش وجود ندارد</span>");
    }
}

seeapartement::~seeapartement()
{
    delete ui;
}
