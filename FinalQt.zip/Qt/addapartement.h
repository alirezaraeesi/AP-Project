#ifndef ADDAPARTEMENT_H
#define ADDAPARTEMENT_H

#include <QDialog>

namespace Ui {
class addApartement;
}

class addApartement : public QDialog
{
    Q_OBJECT

public:
    explicit addApartement(QWidget *parent = nullptr);
    int get();
    ~addApartement();

private slots:
    void on_confirm_clicked();

private:
    Ui::addApartement *ui;
};

#endif // ADDAPARTEMENT_H
