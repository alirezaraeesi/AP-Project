#ifndef SEENVILLA_H
#define SEENVILLA_H

#include <QDialog>

namespace Ui {
class seenvilla;
}

class seenvilla : public QDialog
{
    Q_OBJECT

public:
    explicit seenvilla(QWidget *parent = nullptr);
    ~seenvilla();

private:
    Ui::seenvilla *ui;
};

#endif // SEENVILLA_H
