#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "usersignin.h"
#include "usersignup.h"
#include "usermentpanel.h"
#include "managersignin.h"
#include "managersignup.h"
#include <QPalette>
#include "north.h"
#include <QPushButton>
#include<iostream>
#include<vector>
#include<fstream>
using namespace std;

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);

}
void MainWindow::set(north n)
{
    no.push_back(n);
}
vector<north> MainWindow::get()
{
    return this->no;
}




MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::on_signin_clicked()
{
    managerSignin m;
    userSignin u;
    if(ui->radioButtonm->isChecked())
    {
        m.exec();
    }
    else if(ui->radioButtonu->isChecked())
    {
        u.exec();
    }
    else
    {
        ui->error->setText("<span style=\"color:red;\">لطفا انتخاب کنید که به چه عنوان میخواهید وارد سیستم شوید</span>");
    }
}

void MainWindow::on_signup_clicked()
{
    managerSignup m;
    userSignup u;
    if(ui->radioButtonm->isChecked())
    {
        this->close();
        m.exec();
    }
    else if(ui->radioButtonu->isChecked())
    {
        u.exec();
    }
    else
    {
        ui->error->setText("<span style=\"color:red;\">لطفا انتخاب کنید که به چه عنوان میخواهید وارد سیستم شوید</span>");
    }


}
