#pragma once
#include <iostream>
using namespace std;
class house
{
protected:
	int totalArea;
	int baseCost;
	string address;
public:
	house();
	house(int areabuilt, int basscost, string address);
	void setTotalArea(int _area);
	int getTotalArea();
	void setaddress(string address);
	string getaddress();
	void setbasscost(int basscost);
	int getbasscost();
	~house();
};

