#include "usermentpanel.h"
#include "ui_usermentpanel.h"
#include "observe.h"
usermentPanel::usermentPanel(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::usermentPanel)
{
    ui->setupUi(this);
}

usermentPanel::~usermentPanel()
{
    delete ui;
}

void usermentPanel::on_pushButton_5_clicked()
{
    observe o;
    o.exec();
}
