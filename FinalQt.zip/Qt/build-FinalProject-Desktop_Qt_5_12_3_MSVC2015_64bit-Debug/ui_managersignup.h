/********************************************************************************
** Form generated from reading UI file 'managersignup.ui'
**
** Created by: Qt User Interface Compiler version 5.12.3
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MANAGERSIGNUP_H
#define UI_MANAGERSIGNUP_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QCalendarWidget>
#include <QtWidgets/QDialog>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>

QT_BEGIN_NAMESPACE

class Ui_managerSignup
{
public:
    QLabel *label_6;
    QLineEdit *password;
    QLineEdit *repassword;
    QLabel *error;
    QLabel *label_2;
    QLabel *label_5;
    QLineEdit *lname;
    QPushButton *confirm;
    QLineEdit *fname;
    QLineEdit *username;
    QLabel *label;
    QCalendarWidget *birthday;
    QLabel *label_7;
    QLabel *label_3;
    QLabel *label_4;

    void setupUi(QDialog *managerSignup)
    {
        if (managerSignup->objectName().isEmpty())
            managerSignup->setObjectName(QString::fromUtf8("managerSignup"));
        managerSignup->resize(480, 510);
        label_6 = new QLabel(managerSignup);
        label_6->setObjectName(QString::fromUtf8("label_6"));
        label_6->setGeometry(QRect(320, 394, 65, 25));
        QFont font;
        font.setFamily(QString::fromUtf8("Nasim"));
        font.setPointSize(12);
        label_6->setFont(font);
        password = new QLineEdit(managerSignup);
        password->setObjectName(QString::fromUtf8("password"));
        password->setGeometry(QRect(180, 362, 133, 20));
        password->setEchoMode(QLineEdit::Password);
        repassword = new QLineEdit(managerSignup);
        repassword->setObjectName(QString::fromUtf8("repassword"));
        repassword->setGeometry(QRect(180, 399, 133, 20));
        repassword->setEchoMode(QLineEdit::Password);
        error = new QLabel(managerSignup);
        error->setObjectName(QString::fromUtf8("error"));
        error->setGeometry(QRect(110, 480, 291, 20));
        error->setLayoutDirection(Qt::RightToLeft);
        label_2 = new QLabel(managerSignup);
        label_2->setObjectName(QString::fromUtf8("label_2"));
        label_2->setGeometry(QRect(318, 49, 16, 25));
        label_2->setFont(font);
        label_5 = new QLabel(managerSignup);
        label_5->setObjectName(QString::fromUtf8("label_5"));
        label_5->setGeometry(QRect(320, 357, 40, 25));
        label_5->setFont(font);
        lname = new QLineEdit(managerSignup);
        lname->setObjectName(QString::fromUtf8("lname"));
        lname->setGeometry(QRect(178, 90, 133, 20));
        confirm = new QPushButton(managerSignup);
        confirm->setObjectName(QString::fromUtf8("confirm"));
        confirm->setGeometry(QRect(210, 440, 81, 31));
        QFont font1;
        font1.setFamily(QString::fromUtf8("B Sara"));
        font1.setPointSize(10);
        font1.setBold(false);
        font1.setWeight(50);
        confirm->setFont(font1);
        confirm->setCursor(QCursor(Qt::PointingHandCursor));
        confirm->setStyleSheet(QString::fromUtf8("background:rgb(85, 255, 127)"));
        fname = new QLineEdit(managerSignup);
        fname->setObjectName(QString::fromUtf8("fname"));
        fname->setGeometry(QRect(178, 53, 133, 20));
        QSizePolicy sizePolicy(QSizePolicy::Expanding, QSizePolicy::Expanding);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(fname->sizePolicy().hasHeightForWidth());
        fname->setSizePolicy(sizePolicy);
        fname->setMaximumSize(QSize(500, 200));
        username = new QLineEdit(managerSignup);
        username->setObjectName(QString::fromUtf8("username"));
        username->setGeometry(QRect(180, 325, 133, 20));
        label = new QLabel(managerSignup);
        label->setObjectName(QString::fromUtf8("label"));
        label->setGeometry(QRect(205, 0, 81, 31));
        QFont font2;
        font2.setFamily(QString::fromUtf8("Nasim"));
        font2.setPointSize(17);
        font2.setBold(false);
        font2.setWeight(50);
        label->setFont(font2);
        birthday = new QCalendarWidget(managerSignup);
        birthday->setObjectName(QString::fromUtf8("birthday"));
        birthday->setGeometry(QRect(15, 125, 296, 183));
        birthday->setMaximumSize(QSize(16777215, 1000));
        label_7 = new QLabel(managerSignup);
        label_7->setObjectName(QString::fromUtf8("label_7"));
        label_7->setGeometry(QRect(318, 125, 44, 25));
        label_7->setFont(font);
        label_3 = new QLabel(managerSignup);
        label_3->setObjectName(QString::fromUtf8("label_3"));
        label_3->setGeometry(QRect(318, 85, 58, 25));
        label_3->setFont(font);
        label_4 = new QLabel(managerSignup);
        label_4->setObjectName(QString::fromUtf8("label_4"));
        label_4->setGeometry(QRect(320, 320, 49, 25));
        label_4->setFont(font);

        retranslateUi(managerSignup);

        QMetaObject::connectSlotsByName(managerSignup);
    } // setupUi

    void retranslateUi(QDialog *managerSignup)
    {
        managerSignup->setWindowTitle(QApplication::translate("managerSignup", "Dialog", nullptr));
        label_6->setText(QApplication::translate("managerSignup", "\330\252\332\251\330\261\330\247\330\261 \330\261\331\205\330\262 \330\271\330\250\331\210\330\261:", nullptr));
        error->setText(QString());
        label_2->setText(QApplication::translate("managerSignup", "\331\206\330\247\331\205:", nullptr));
        label_5->setText(QApplication::translate("managerSignup", "\330\261\331\205\330\262 \330\271\330\250\331\210\330\261:", nullptr));
        confirm->setText(QApplication::translate("managerSignup", "\330\252\330\243\333\214\333\214\330\257 \330\253\330\250\330\252 \331\206\330\247\331\205", nullptr));
        label->setText(QApplication::translate("managerSignup", "\331\201\330\261\331\205 \330\253\330\250\330\252 \331\206\330\247\331\205", nullptr));
        label_7->setText(QApplication::translate("managerSignup", "\330\252\330\247\330\261\333\214\330\256 \330\252\331\210\331\204\330\257:", nullptr));
        label_3->setText(QApplication::translate("managerSignup", "\331\206\330\247\331\205 \330\256\330\247\331\206\331\210\330\247\330\257\332\257\333\214:", nullptr));
        label_4->setText(QApplication::translate("managerSignup", "\331\206\330\247\331\205 \332\251\330\247\330\261\330\250\330\261\333\214:", nullptr));
    } // retranslateUi

};

namespace Ui {
    class managerSignup: public Ui_managerSignup {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MANAGERSIGNUP_H
