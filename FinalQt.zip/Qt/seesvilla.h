#ifndef SEESVILLA_H
#define SEESVILLA_H

#include <QDialog>

namespace Ui {
class seesvilla;
}

class seesvilla : public QDialog
{
    Q_OBJECT

public:
    explicit seesvilla(QWidget *parent = nullptr);
    ~seesvilla();

private:
    Ui::seesvilla *ui;
};

#endif // SEESVILLA_H
